import { useState, useEffect, useMemo, useRef } from 'react';
import { Game, ActiveTab } from './types';
import gamesData from './data/games.json';

// Import subcomponents
import Navbar from './components/Navbar';
import HeroBanner from './components/HeroBanner';
import GameCard from './components/GameCard';
import GameDetailsModal from './components/GameDetailsModal';
import AboutView from './components/AboutView';
import ContactView from './components/ContactView';
import GamePlayer from './components/GamePlayer';

// Icons
import { 
  Gamepad2, Sparkles, Trophy, Clock, Heart, Search, Filter, 
  ArrowUpDown, RefreshCw, Star, Info, PhoneCall, Check, ArrowRight
} from 'lucide-react';

const CATEGORIES = [
  "Action", "Adventure", "Arcade", "Racing", "Bike Games", "Car Games",
  "Sports", "Puzzle", "Strategy", "Card Games", "Rummy", "Ludo",
  "Casino", "Shooting", "Multiplayer", "Simulation"
];

export default function App() {
  // Global application states
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [sortBy, setSortBy] = useState<'rating' | 'name' | 'default'>('default');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  
  // Modal states
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);

  // Favorites (wishlist) loaded from localStorage
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('gameverse_favorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Infinite Scroll State
  const [itemsLimit, setItemsLimit] = useState<number>(16);
  const [isLoadingMore, setIsLoadingMore] = useState<boolean>(false);
  const loaderRef = useRef<HTMLDivElement>(null);

  // Safe cast of loaded games JSON
  const allGames = useMemo<Game[]>(() => {
    return gamesData as Game[];
  }, []);

  // Sync favorites with localStorage
  useEffect(() => {
    localStorage.setItem('gameverse_favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Handle active tab scroll to top
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setItemsLimit(16); // Reset pagination limits on tab change
  }, [activeTab, selectedCategory]);

  // Toggle Favorite handler
  const handleToggleFavorite = (gameId: string) => {
    setFavorites((prev) => 
      prev.includes(gameId) 
        ? prev.filter((id) => id !== gameId) 
        : [...prev, gameId]
    );
  };

  // Safe In-App Arcade Runner or External Play Now opener
  const [activePlayingGame, setActivePlayingGame] = useState<Game | null>(null);

  const handlePlayGame = (game: Game) => {
    setActivePlayingGame(game);
  };

  // Extract Top 5 High-Rated Games for the Hero spotlight
  const featuredGames = useMemo(() => {
    return allGames
      .filter(g => g.rating >= 4.7)
      .slice(0, 5);
  }, [allGames]);

  // Sliced Categories for Home Feed
  const trendingGames = useMemo(() => {
    return allGames.slice(5, 13); // Hand-sliced trending subset
  }, [allGames]);

  const recentlyAddedGames = useMemo(() => {
    return allGames.slice(13, 21); // Hand-sliced new releases subset
  }, [allGames]);

  const topPlayedGames = useMemo(() => {
    return [...allGames]
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 8); // Top rated overall
  }, [allGames]);

  // Main list builder with sorting, filtering, and searching
  const filteredAndSortedGames = useMemo(() => {
    let result = [...allGames];

    // 1. Search Query filter
    if (searchQuery.trim() !== '') {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        g => g.name.toLowerCase().includes(query) ||
             g.developer.toLowerCase().includes(query) ||
             g.category.toLowerCase().includes(query) ||
             g.description.toLowerCase().includes(query)
      );
    }

    // 2. Category filter
    if (selectedCategory !== '') {
      result = result.filter(g => g.category.toLowerCase() === selectedCategory.toLowerCase());
    }

    // 3. Tab Route constraints
    if (activeTab === 'popular') {
      result = result.filter(g => g.rating >= 4.6);
    } else if (activeTab === 'new') {
      // Simulate new releases by taking later IDs
      result = result.filter((_, idx) => idx % 3 === 0);
    } else if (activeTab === 'trending') {
      // Sliced trending subset
      result = result.filter((_, idx) => idx % 4 === 1);
    } else if (activeTab === 'favorites') {
      result = result.filter(g => favorites.includes(g.id));
    }

    // 4. Sorting logic
    if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'name') {
      result.sort((a, b) => a.name.localeCompare(b.name));
    }

    return result;
  }, [allGames, searchQuery, selectedCategory, activeTab, sortBy, favorites]);

  // Slices games for infinite scrolling
  const visibleGames = useMemo(() => {
    return filteredAndSortedGames.slice(0, itemsLimit);
  }, [filteredAndSortedGames, itemsLimit]);

  // Infinite Scroll Trigger (Manual show-more simulator with loading animation)
  const handleLoadMore = () => {
    setIsLoadingMore(true);
    setTimeout(() => {
      setItemsLimit((prev) => prev + 12);
      setIsLoadingMore(false);
    }, 800); // 800ms elegant neon spinner delay
  };

  // Recommendation similar games selector
  const similarGames = useMemo(() => {
    if (!selectedGame) return [];
    return allGames
      .filter(g => g.category === selectedGame.category && g.id !== selectedGame.id)
      .slice(0, 8);
  }, [selectedGame, allGames]);

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-all duration-300 ${
      isDarkMode ? 'bg-[#07080c] text-white' : 'bg-[#f4f6fa] text-neutral-800'
    }`}>
      
      {/* Navigation Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          // Auto clear category when swapping to distinct tabs
          if (tab !== 'categories' && tab !== 'search') {
            setSelectedCategory('');
          }
        }}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        favoritesCount={favorites.length}
      />

      {/* Main Container Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* VIEW: HOME VIEW */}
        {activeTab === 'home' && searchQuery === '' && (
          <div className="space-y-12 animate-fade-in">
            {/* Majestic Hero Banner Spotlights */}
            <HeroBanner
              featuredGames={featuredGames}
              onPlayGame={handlePlayGame}
              onOpenDetails={(game) => setSelectedGame(game)}
              isDarkMode={isDarkMode}
            />

            {/* Quick Categories horizontal rail */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Gamepad2 className="w-5 h-5 text-emerald-400" />
                  <h2 className="font-display font-extrabold text-lg sm:text-xl tracking-tight">Explore Categories</h2>
                </div>
                <button 
                  onClick={() => setActiveTab('categories')}
                  className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
                >
                  View All Genres
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="flex gap-2.5 overflow-x-auto pb-3 no-scrollbar shrink-0">
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedCategory(cat);
                      setActiveTab('categories');
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-semibold tracking-wide border cursor-pointer transition-all shrink-0 ${
                      isDarkMode
                        ? 'bg-white/5 border-white/10 text-neutral-300 hover:border-emerald-500/40 hover:text-emerald-400'
                        : 'bg-white/65 border-black/10 text-neutral-600 hover:border-emerald-500/30 hover:text-emerald-500'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* SECTION 1: Trending Games Slider */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-5 h-5 text-emerald-400" />
                <h2 className="font-display font-extrabold text-lg sm:text-xl tracking-tight">Trending Games</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {trendingGames.map((game) => (
                  <GameCard
                    key={game.id}
                    game={game}
                    isFavorited={favorites.includes(game.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onPlayGame={handlePlayGame}
                    onOpenDetails={(g) => setSelectedGame(g)}
                    isDarkMode={isDarkMode}
                  />
                ))}
              </div>
            </div>

            {/* SECTION 2: Recently Added Games */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                <h2 className="font-display font-extrabold text-lg sm:text-xl tracking-tight">Recently Added Games</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {recentlyAddedGames.map((game) => (
                  <GameCard
                    key={game.id}
                    game={game}
                    isFavorited={favorites.includes(game.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onPlayGame={handlePlayGame}
                    onOpenDetails={(g) => setSelectedGame(g)}
                    isDarkMode={isDarkMode}
                  />
                ))}
              </div>
            </div>

            {/* SECTION 3: Top Played Games */}
            <div className={`p-6 sm:p-8 rounded-3xl border backdrop-blur-md ${
              isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white/65 border-black/10'
            }`}>
              <div className="flex items-center gap-2 mb-6">
                <Trophy className="w-5.5 h-5.5 text-yellow-500" />
                <h2 className="font-display font-extrabold text-xl tracking-tight">Top Played Overall</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {topPlayedGames.map((game) => (
                  <GameCard
                    key={game.id}
                    game={game}
                    isFavorited={favorites.includes(game.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onPlayGame={handlePlayGame}
                    onOpenDetails={(g) => setSelectedGame(g)}
                    isDarkMode={isDarkMode}
                  />
                ))}
              </div>
            </div>

          </div>
        )}

        {/* VIEW: CATEGORIES GRID VIEW */}
        {activeTab === 'categories' && selectedCategory === '' && searchQuery === '' && (
          <div className="space-y-6 animate-fade-in">
            <div className="space-y-1.5">
              <h2 className="font-display font-black text-2xl sm:text-3xl tracking-tight">Browse Genres</h2>
              <p className={`text-xs sm:text-sm ${isDarkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
                Explore from over 200 high fidelity web-based play-stations.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {CATEGORIES.map((cat, idx) => {
                const count = allGames.filter(g => g.category === cat).length;
                return (
                  <div
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`p-6 rounded-2xl cursor-pointer border text-center transition-all duration-300 hover:scale-102 flex flex-col justify-between h-36 relative overflow-hidden group backdrop-blur-md ${
                      isDarkMode
                        ? 'bg-white/5 border-white/10 hover:border-emerald-500 hover:shadow-emerald-500/10'
                        : 'bg-white/65 border-black/10 hover:border-emerald-500 shadow-sm hover:shadow-md'
                    }`}
                  >
                    <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-gradient-to-br from-emerald-500/5 to-cyan-500/5 -mr-8 -mt-8 transition-transform group-hover:scale-125" />
                    
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 mx-auto">
                      <Gamepad2 className="w-5.5 h-5.5 text-emerald-400" />
                    </div>

                    <div className="relative z-10 space-y-1">
                      <h3 className="font-display font-bold text-sm sm:text-base">{cat}</h3>
                      <span className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider">{count} Games</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* LISTING VIEWS WITH FILTER/SORT SIDEBAR BAR */}
        {((activeTab !== 'home' || searchQuery !== '') && (activeTab !== 'categories' || selectedCategory !== '') && activeTab !== 'about' && activeTab !== 'contact') && (
          <div className="space-y-6 animate-fade-in">
            
            {/* Header Description Title */}
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div className="space-y-1">
                {selectedCategory && (
                  <button 
                    onClick={() => setSelectedCategory('')}
                    className="text-xs font-semibold text-neutral-400 hover:text-emerald-400 mb-1 flex items-center gap-1 cursor-pointer"
                  >
                    &larr; Back to Genres
                  </button>
                )}
                <h2 className="font-display font-black text-2xl sm:text-3xl tracking-tight capitalize">
                  {searchQuery !== '' 
                    ? `Search results for "${searchQuery}"`
                    : selectedCategory !== ''
                      ? `${selectedCategory} Games`
                      : activeTab === 'favorites'
                        ? 'My Wishlist'
                        : `${activeTab} Games`
                  }
                </h2>
                <p className={`text-xs sm:text-sm ${isDarkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
                  Showing {filteredAndSortedGames.length} verified web titles.
                </p>
              </div>

              {/* Filtering Controls Bar */}
              <div className="flex flex-wrap items-center gap-3 shrink-0">
                
                {/* Category Dropdown (if not inside specific category) */}
                {!selectedCategory && (
                  <div className="flex items-center gap-1.5 relative">
                    <Filter className="w-4 h-4 text-neutral-400" />
                    <select
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value)}
                      className={`text-xs font-semibold px-3 py-2 rounded-xl border outline-none ${
                        isDarkMode 
                          ? 'bg-white/5 border-white/10 text-neutral-300 focus:border-emerald-500' 
                          : 'bg-white border-black/15 text-neutral-600 focus:border-emerald-500'
                      }`}
                    >
                      <option value="">All Categories</option>
                      {CATEGORIES.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Sort dropdown */}
                <div className="flex items-center gap-1.5">
                  <ArrowUpDown className="w-4 h-4 text-neutral-400" />
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className={`text-xs font-semibold px-3 py-2 rounded-xl border outline-none ${
                      isDarkMode 
                        ? 'bg-white/5 border-white/10 text-neutral-300 focus:border-emerald-500' 
                        : 'bg-white border-black/15 text-neutral-600 focus:border-emerald-500'
                    }`}
                  >
                    <option value="default">Default Sort</option>
                    <option value="rating">Top Rated</option>
                    <option value="name">Alphabetical</option>
                  </select>
                </div>

                {/* Reset button if active filter/search */}
                {(searchQuery || selectedCategory || sortBy !== 'default') && (
                  <button
                    onClick={() => {
                      setSearchQuery('');
                      setSelectedCategory('');
                      setSortBy('default');
                    }}
                    className={`p-2 rounded-xl border text-neutral-400 hover:text-white transition cursor-pointer ${
                      isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-black/15'
                    }`}
                    title="Reset Filters"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                )}

              </div>
            </div>

            {/* Games Card Grid */}
            {visibleGames.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {visibleGames.map((game) => (
                  <GameCard
                    key={game.id}
                    game={game}
                    isFavorited={favorites.includes(game.id)}
                    onToggleFavorite={handleToggleFavorite}
                    onPlayGame={handlePlayGame}
                    onOpenDetails={(g) => setSelectedGame(g)}
                    isDarkMode={isDarkMode}
                  />
                ))}
              </div>
            ) : (
              <div className={`p-16 rounded-3xl border text-center space-y-4 max-w-lg mx-auto backdrop-blur-md ${
                isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white/65 border-black/10'
              }`}>
                <Gamepad2 className="w-12 h-12 text-neutral-600 mx-auto" />
                <h3 className="font-display font-bold text-lg">No games found</h3>
                <p className={`text-xs leading-relaxed ${isDarkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
                  We couldn't locate any games matching your active filters. Try clearing search queries or choosing another genre.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('');
                    setSortBy('default');
                  }}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-black bg-emerald-500 hover:bg-emerald-400 shadow-md cursor-pointer duration-300"
                >
                  Clear All Filters
                </button>
              </div>
            )}

            {/* Infinite scrolling interactive sensor loading */}
            {filteredAndSortedGames.length > visibleGames.length && (
              <div className="pt-8 text-center" ref={loaderRef}>
                <button
                  onClick={handleLoadMore}
                  disabled={isLoadingMore}
                  className={`inline-flex items-center gap-2 px-6 py-3.5 rounded-2xl border text-xs font-bold tracking-wider uppercase transition cursor-pointer duration-300 ${
                    isDarkMode 
                      ? 'bg-white/5 border-white/10 text-neutral-300 hover:border-emerald-500 hover:text-emerald-400 shadow-sm' 
                      : 'bg-white border-black/10 text-neutral-600 hover:border-emerald-500 hover:text-emerald-500 shadow-sm'
                  }`}
                >
                  {isLoadingMore ? (
                    <>
                      <div className="w-4 h-4 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin" />
                      Loading more titles...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-3.5 h-3.5" />
                      Show More Games
                    </>
                  )}
                </button>
              </div>
            )}

          </div>
        )}

        {/* VIEW: ABOUT VIEW */}
        {activeTab === 'about' && (
          <AboutView isDarkMode={isDarkMode} />
        )}

        {/* VIEW: CONTACT VIEW */}
        {activeTab === 'contact' && (
          <ContactView isDarkMode={isDarkMode} />
        )}

      </main>

      {/* FOOTER */}
      <footer className={`mt-16 border-t transition-all duration-300 ${
        isDarkMode 
          ? 'bg-[#07080c] border-white/5 text-neutral-400' 
          : 'bg-white border-black/5 text-neutral-600'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            
            {/* Brand Intro info */}
            <div className="space-y-4 md:col-span-2">
              <div className="flex items-center gap-2">
                <Gamepad2 className="w-6 h-6 text-emerald-400" />
                <span className="font-display font-black text-lg bg-gradient-to-r from-emerald-400 to-cyan-500 bg-clip-text text-transparent">
                  GameVerse
                </span>
              </div>
              <p className="text-xs leading-relaxed max-w-sm">
                Google Play Store style premium web games indexing station. Explore over 200 fully verified web arcade titles across 16 different categories instantly on your mobile, tablet, or desktop.
              </p>
            </div>

            {/* Sliced Navigation links */}
            <div>
              <h4 className="font-display font-bold text-xs uppercase tracking-wider text-neutral-400 mb-4">
                Explore Genres
              </h4>
              <ul className="space-y-2 text-xs">
                <li>
                  <button 
                    onClick={() => { setSelectedCategory('action'); setActiveTab('categories'); }}
                    className="hover:text-emerald-400 transition cursor-pointer"
                  >
                    Action Brawlers
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setSelectedCategory('racing'); setActiveTab('categories'); }}
                    className="hover:text-emerald-400 transition cursor-pointer"
                  >
                    High-Speed Racing
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setSelectedCategory('puzzle'); setActiveTab('categories'); }}
                    className="hover:text-emerald-400 transition cursor-pointer"
                  >
                    Mind Puzzles
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => { setSelectedCategory('sports'); setActiveTab('categories'); }}
                    className="hover:text-emerald-400 transition cursor-pointer"
                  >
                    Athletic Sports
                  </button>
                </li>
              </ul>
            </div>

            {/* Quick platform links */}
            <div>
              <h4 className="font-display font-bold text-xs uppercase tracking-wider text-neutral-400 mb-4">
                Platform
              </h4>
              <ul className="space-y-2 text-xs">
                <li>
                  <button onClick={() => setActiveTab('about')} className="hover:text-emerald-400 transition cursor-pointer">
                    Help & FAQs
                  </button>
                </li>
                <li>
                  <button onClick={() => setActiveTab('contact')} className="hover:text-emerald-400 transition cursor-pointer">
                    Developer Portal
                  </button>
                </li>
                <li>
                  <a href="https://poki.com" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition cursor-pointer">
                    Partner Network
                  </a>
                </li>
              </ul>
            </div>

          </div>

          <div className="mt-8 pt-8 border-t border-neutral-900/10 dark:border-neutral-900/40 text-center text-[10px] space-y-2">
            <p>&copy; {new Date().getFullYear()} GameVerse Curated Web Gaming Portal. All rights reserved.</p>
            <p className="text-neutral-500 max-w-xl mx-auto leading-relaxed">
              GameVerse does not host or execute binary files on server hardware. All play buttons securely route to official developer-owned external sites. Verify secure browsing habits.
            </p>
          </div>
        </div>
      </footer>

      {/* IMMERSIVE DETAILED GAME MODAL */}
      {selectedGame && (
        <GameDetailsModal
          game={selectedGame}
          onClose={() => setSelectedGame(null)}
          isFavorited={favorites.includes(selectedGame.id)}
          onToggleFavorite={handleToggleFavorite}
          onPlayGame={handlePlayGame}
          similarGames={similarGames}
          onSelectSimilarGame={(sg) => setSelectedGame(sg)}
          isDarkMode={isDarkMode}
        />
      )}

      {/* ACTIVE PLAYING ARCADE ENGINE PLAYER */}
      {activePlayingGame && (
        <GamePlayer
          game={activePlayingGame}
          isDarkMode={isDarkMode}
          onClose={() => setActivePlayingGame(null)}
        />
      )}

    </div>
  );
}
