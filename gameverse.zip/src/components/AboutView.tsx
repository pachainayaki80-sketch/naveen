import { Info, HelpCircle, ShieldAlert, Zap, Globe, Sparkles } from 'lucide-react';

interface AboutViewProps {
  isDarkMode: boolean;
}

export default function AboutView({ isDarkMode }: AboutViewProps) {
  const faqs = [
    {
      q: "What is GameVerse?",
      a: "GameVerse is a modern, high-speed, Google Play Store inspired web game cataloging platform. We index and catalog over 200 premium online web games across 16 genres. You can find, search, filter, and instantly play any game directly on its official portal without downloading or installing any files."
    },
    {
      q: "Are the games on GameVerse free to play?",
      a: "Yes! All games curated on GameVerse are 100% free-to-play web-based experiences. When you click 'Play Now', the platform securely routes you directly to the developer's official web domain or safe hosting servers where the game loads instantly in a new browser tab."
    },
    {
      q: "How does the Wishlist / Favorites feature work?",
      a: "Our wishlist allows you to bookmark games so you don't lose track of your favorites. It uses browser-level secure localStorage persistence, meaning your favorites are instantly saved on your device and will be available every time you return to GameVerse."
    },
    {
      q: "Is playing games on GameVerse safe?",
      a: "Absolutely. We only catalog secure web games that use modern HTML5 web standards. They execute within a secure client-side sandbox in your browser and do not require installing any executable code. We also perform visual checks to guarantee catalog correctness."
    }
  ];

  return (
    <div className="space-y-10 animate-fade-in py-4 max-w-4xl mx-auto">
      
      {/* Branding Hero Card */}
      <div className={`relative rounded-3xl p-8 md:p-12 overflow-hidden border backdrop-blur-md ${
        isDarkMode 
          ? 'bg-white/5 border-white/10' 
          : 'bg-white/65 border-black/10 shadow-sm'
      }`}>
        <div className="absolute top-0 right-0 -translate-y-12 translate-x-12 w-64 h-64 rounded-full bg-emerald-500/10 blur-3xl" />
        <div className="absolute bottom-0 left-0 translate-y-12 -translate-x-12 w-64 h-64 rounded-full bg-cyan-500/10 blur-3xl" />

        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-4.5 h-4.5" />
            <span>Curating Web Arcade Culture</span>
          </div>
          
          <h2 className="font-display font-extrabold text-3xl sm:text-4xl tracking-tight">
            The Ultimate Portal for Online Browser Gaming
          </h2>
          
          <p className={`text-sm sm:text-base leading-relaxed ${
            isDarkMode ? 'text-neutral-300' : 'text-neutral-600'
          }`}>
            GameVerse was built with a single goal: to curate the vast, scattered universe of web-based browser games into a beautiful, organized, Google Play-style dashboard. By compiling the highest quality titles from across the net, we provide instant access to clean gaming experiences with premium layouts and lightning-fast search capabilities.
          </p>
        </div>
      </div>

      {/* Accordion FAQs */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <HelpCircle className="w-5 h-5 text-emerald-400" />
          <h3 className="font-display font-bold text-lg">Frequently Asked Questions</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className={`p-5 rounded-2xl border transition-all duration-200 backdrop-blur-md ${
                isDarkMode 
                  ? 'bg-white/5 border-white/10 hover:border-emerald-500/30' 
                  : 'bg-white/65 border-black/10 shadow-sm hover:shadow-md'
              }`}
            >
              <h4 className={`font-display font-semibold text-sm sm:text-base mb-2 ${
                isDarkMode ? 'text-emerald-300' : 'text-emerald-600'
              }`}>
                {faq.q}
              </h4>
              <p className={`text-xs sm:text-sm leading-relaxed ${
                isDarkMode ? 'text-neutral-400' : 'text-neutral-600'
              }`}>
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Feature Badges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className={`p-5 rounded-2xl border flex items-start gap-3 backdrop-blur-md ${
          isDarkMode ? 'bg-white/5 border-white/10' : 'bg-black/5 border-black/10'
        }`}>
          <Zap className="w-6 h-6 text-emerald-400 shrink-0" />
          <div>
            <h5 className="font-semibold text-xs sm:text-sm mb-1">Instant Loading</h5>
            <p className="text-[11px] text-neutral-400 leading-relaxed">No downloads, no installations. Tap and play in 1 second.</p>
          </div>
        </div>

        <div className={`p-5 rounded-2xl border flex items-start gap-3 backdrop-blur-md ${
          isDarkMode ? 'bg-white/5 border-white/10' : 'bg-black/5 border-black/10'
        }`}>
          <Globe className="w-6 h-6 text-cyan-400 shrink-0" />
          <div>
            <h5 className="font-semibold text-xs sm:text-sm mb-1">200+ Handpicked Games</h5>
            <p className="text-[11px] text-neutral-400 leading-relaxed">Curated catalog representing the absolute best web titles.</p>
          </div>
        </div>

        <div className={`p-5 rounded-2xl border flex items-start gap-3 backdrop-blur-md ${
          isDarkMode ? 'bg-white/5 border-white/10' : 'bg-black/5 border-black/10'
        }`}>
          <ShieldAlert className="w-6 h-6 text-emerald-400 shrink-0" />
          <div>
            <h5 className="font-semibold text-xs sm:text-sm mb-1">Secure & Sandbox Safe</h5>
            <p className="text-[11px] text-neutral-400 leading-relaxed">Adheres strictly to modern sandboxed browser safety protocols.</p>
          </div>
        </div>
      </div>

      {/* Dev / Legal disclaimer footer */}
      <div className={`p-5 rounded-2xl text-center text-xs leading-relaxed border backdrop-blur-md ${
        isDarkMode ? 'bg-white/5 border-white/10 text-neutral-400' : 'bg-black/5 border-black/10 text-neutral-500'
      }`}>
        <Info className="w-5 h-5 mx-auto mb-2 text-neutral-400" />
        <p>
          <b>Legal disclaimer:</b> All trademark rights, branding layouts, game logos, and external websites are properties of their respective developers or owners. GameVerse acts as a curated web bookmarking and aggregation service only.
        </p>
      </div>

    </div>
  );
}
