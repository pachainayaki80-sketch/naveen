import { useState, FormEvent, ChangeEvent } from 'react';
import { Mail, Phone, Send, Sparkles, AlertCircle, CheckCircle2, MessageSquare } from 'lucide-react';
import { ContactForm } from '../types';

interface ContactViewProps {
  isDarkMode: boolean;
}

export default function ContactView({ isDarkMode }: ContactViewProps) {
  const [formData, setFormData] = useState<ContactForm>({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setStatus('error');
      return;
    }

    setStatus('loading');
    
    // Simulate successful API response
    setTimeout(() => {
      setStatus('success');
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 1500);
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
    if (status === 'error') setStatus('idle');
  };

  return (
    <div className="animate-fade-in py-4 max-w-4xl mx-auto space-y-8">
      
      {/* Intro Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          <MessageSquare className="w-3.5 h-3.5" />
          Get In Touch
        </div>
        <h2 className="font-display font-extrabold text-2xl sm:text-3xl tracking-tight">
          Developer Support & Game Submission
        </h2>
        <p className={`text-xs sm:text-sm max-w-lg mx-auto ${isDarkMode ? 'text-neutral-400' : 'text-neutral-500'}`}>
          Are you a web developer who wants to showcase your game on GameVerse? Or did you run into catalog problems? Reach out below!
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-8 items-start">
        
        {/* Left Side: Form - 3/5 width */}
        <div className={`md:col-span-3 rounded-2xl p-6 md:p-8 border backdrop-blur-md ${
          isDarkMode 
            ? 'bg-white/5 border-white/10' 
            : 'bg-white/65 border-black/10 shadow-sm'
        }`}>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Name */}
            <div>
              <label className="block text-xs font-semibold text-neutral-400 mb-1">Your Name *</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="eg. Alex Chen"
                className={`w-full px-4 py-2.5 rounded-xl text-xs sm:text-sm outline-none transition-all duration-200 border ${
                  isDarkMode 
                    ? 'bg-white/5 border-white/10 text-white focus:bg-white/10 focus:border-emerald-500' 
                    : 'bg-black/5 border-black/10 text-neutral-800 focus:bg-white focus:border-emerald-500'
                }`}
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs font-semibold text-neutral-400 mb-1">Your Email *</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="eg. alex@example.com"
                className={`w-full px-4 py-2.5 rounded-xl text-xs sm:text-sm outline-none transition-all duration-200 border ${
                  isDarkMode 
                    ? 'bg-white/5 border-white/10 text-white focus:bg-white/10 focus:border-emerald-500' 
                    : 'bg-black/5 border-black/10 text-neutral-800 focus:bg-white focus:border-emerald-500'
                }`}
                required
              />
            </div>

            {/* Subject */}
            <div>
              <label className="block text-xs font-semibold text-neutral-400 mb-1">Subject</label>
              <input
                type="text"
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                placeholder="eg. Submit my game 'SpeedRacer'"
                className={`w-full px-4 py-2.5 rounded-xl text-xs sm:text-sm outline-none transition-all duration-200 border ${
                  isDarkMode 
                    ? 'bg-white/5 border-white/10 text-white focus:bg-white/10 focus:border-emerald-500' 
                    : 'bg-black/5 border-black/10 text-neutral-800 focus:bg-white focus:border-emerald-500'
                }`}
              />
            </div>

            {/* Message */}
            <div>
              <label className="block text-xs font-semibold text-neutral-400 mb-1">Message *</label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                rows={4}
                placeholder="Write your suggestions, request catalog updates or submit your web game URL details..."
                className={`w-full px-4 py-2.5 rounded-xl text-xs sm:text-sm outline-none transition-all duration-200 border resize-none ${
                  isDarkMode 
                    ? 'bg-white/5 border-white/10 text-white focus:bg-white/10 focus:border-emerald-500' 
                    : 'bg-black/5 border-black/10 text-neutral-800 focus:bg-white focus:border-emerald-500'
                }`}
                required
              />
            </div>

            {/* Alert Messages */}
            {status === 'success' && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs leading-relaxed animate-pulse">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <span>Message received! Our curated cataloging desk will analyze your request and reply within 48 hours.</span>
              </div>
            )}

            {status === 'error' && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-pink-500/10 border border-pink-500/20 text-pink-400 text-xs leading-relaxed">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>Please fill out all required fields to submit.</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={status === 'loading'}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs sm:text-sm tracking-wide transition cursor-pointer disabled:opacity-55 duration-300 shadow-lg shadow-emerald-500/15"
            >
              {status === 'loading' ? (
                <>
                  <div className="w-4 h-4 rounded-full border-2 border-black/30 border-t-black animate-spin" />
                  Sending Message...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Submit Message
                </>
              )}
            </button>

          </form>

        </div>

        {/* Right Side: Info Cards - 2/5 width */}
        <div className="md:col-span-2 space-y-4">
          
          <div className={`p-5 rounded-2xl border backdrop-blur-md ${
            isDarkMode ? 'bg-white/5 border-white/10' : 'bg-black/5 border-black/10'
          }`}>
            <h4 className="font-display font-semibold text-xs uppercase tracking-wide text-neutral-400 mb-3">
              Direct Channels
            </h4>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-[10px] text-neutral-500 uppercase font-bold">Inquiries & Support</span>
                  <a href="mailto:support@gameverse.curated" className="text-xs sm:text-sm font-semibold hover:text-emerald-400 transition break-all">
                    support@gameverse.curated
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="block text-[10px] text-neutral-500 uppercase font-bold">Partnerships Desk</span>
                  <span className="text-xs sm:text-sm font-semibold text-neutral-300">
                    +1-800-PLAY-NOW (Mock)
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-500/10 via-cyan-500/10 to-transparent border border-emerald-500/20 text-center space-y-2 relative overflow-hidden backdrop-blur-md">
            <div className="absolute top-0 right-0 px-2 py-0.5 bg-emerald-500 text-[9px] text-black font-extrabold uppercase rounded-bl-lg">
              PRO
            </div>
            <Sparkles className="w-8 h-8 text-yellow-400 mx-auto animate-bounce" />
            <h5 className="font-display font-bold text-sm">Developer SDK Program</h5>
            <p className="text-[11px] text-neutral-400 leading-relaxed">
              Integrate the GameVerse instant play framework directly into your Unity or WebGL pipeline for zero latency load-outs.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
}
