import React, { MouseEvent } from 'react';
import { Star, Heart, ArrowUpRight, ShieldCheck } from 'lucide-react';
import { Game } from '../types';

interface GameCardProps {
  key?: string | number;
  game: Game;
  isFavorited: boolean;
  onToggleFavorite: (gameId: string) => void;
  onPlayGame: (game: Game) => void;
  onOpenDetails: (game: Game) => void;
  isDarkMode: boolean;
}

export default function GameCard({
  game,
  isFavorited,
  onToggleFavorite,
  onPlayGame,
  onOpenDetails,
  isDarkMode
}: GameCardProps) {

  const handleFavoriteClick = (e: MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(game.id);
  };

  const handlePlayClick = (e: MouseEvent) => {
    e.stopPropagation();
    onPlayGame(game);
  };

  return (
    <div
      id={`game-card-${game.id}`}
      onClick={() => onOpenDetails(game)}
      className={`relative flex flex-col h-full rounded-2xl overflow-hidden cursor-pointer group transition-all duration-300 hover:-translate-y-1.5 border ${
        isDarkMode
          ? 'bg-white/5 border-white/10 hover:border-emerald-500/50 shadow-lg hover:shadow-emerald-500/15 backdrop-blur-md'
          : 'bg-white/65 border-black/10 hover:border-emerald-500/50 hover:shadow-xl shadow-sm backdrop-blur-md'
      }`}
    >
      {/* Game Image Header with Category Badge and Favorite Heart Button */}
      <div className="relative aspect-[4/3] overflow-hidden bg-neutral-950">
        <img
          src={game.image}
          alt={game.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        
        {/* Neon hover grid overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
          <span className="text-[10px] text-neutral-300 font-mono tracking-wider uppercase">
            Click to expand reviews
          </span>
        </div>

        {/* Favorite Button */}
        <button
          onClick={handleFavoriteClick}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all duration-200 shadow-md ${
            isFavorited
              ? 'bg-emerald-500 text-black fill-current'
              : 'bg-black/40 text-white hover:bg-emerald-500 hover:text-black'
          }`}
          title={isFavorited ? 'Remove from favorites' : 'Add to favorites'}
        >
          <Heart className={`w-4.5 h-4.5 ${isFavorited ? 'fill-current scale-110' : ''}`} />
        </button>

        {/* Category Tag */}
        <span className="absolute bottom-3 left-3 px-2.5 py-1 text-[9px] font-bold rounded-full bg-black/60 backdrop-blur-sm text-emerald-400 border border-white/10 uppercase tracking-widest">
          {game.category}
        </span>
      </div>

      {/* Game Metadata & Body */}
      <div className="flex flex-col flex-1 p-4.5 justify-between gap-3">
        <div className="space-y-1">
          {/* Title and Rating Row */}
          <div className="flex items-start justify-between gap-1">
            <h3 className={`font-display font-bold text-sm sm:text-base tracking-tight truncate flex-1 ${
              isDarkMode ? 'text-white' : 'text-neutral-900'
            }`}>
              {game.name}
            </h3>
            
            {/* Play-Store Rating indicator */}
            <div className="flex items-center gap-1 shrink-0 text-yellow-500 bg-yellow-500/5 px-1.5 py-0.5 rounded-md text-xs font-bold">
              <Star className="w-3.5 h-3.5 fill-current" />
              <span>{game.rating}</span>
            </div>
          </div>

          {/* Developer row */}
          <p className="text-[11px] font-bold text-emerald-500 dark:text-emerald-400 truncate">
            {game.developer}
          </p>

          {/* Short description */}
          <p className={`text-xs leading-relaxed line-clamp-2 ${
            isDarkMode ? 'text-neutral-400' : 'text-neutral-500'
          }`}>
            {game.description}
          </p>
        </div>

        {/* Action Row */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-neutral-800/10 dark:border-neutral-800/40">
          <div className="flex items-center gap-1 text-[10px] text-neutral-400 font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Verified safe</span>
          </div>

          <button
            onClick={handlePlayClick}
            className="flex items-center gap-1 px-4 py-2 rounded-xl text-xs font-bold text-white bg-white/10 hover:bg-emerald-500 hover:text-black transition border border-white/20 hover:border-emerald-500 shadow-md cursor-pointer duration-300"
          >
            Play Now
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
