import { X, Star, Heart, Play, Download, ShieldAlert, Sparkles, Building2 } from 'lucide-react';
import { Game } from '../types';

interface GameDetailsModalProps {
  game: Game;
  onClose: () => void;
  isFavorited: boolean;
  onToggleFavorite: (gameId: string) => void;
  onPlayGame: (game: Game) => void;
  similarGames: Game[];
  onSelectSimilarGame: (game: Game) => void;
  isDarkMode: boolean;
}

export default function GameDetailsModal({
  game,
  onClose,
  isFavorited,
  onToggleFavorite,
  onPlayGame,
  similarGames,
  onSelectSimilarGame,
  isDarkMode
}: GameDetailsModalProps) {

  // Dynamic distribution simulation based on game's rating
  const getRatingBarWidth = (stars: number) => {
    const r = game.rating;
    if (stars === 5) return `${Math.min(100, Math.max(10, (r - 3.5) * 60))}%`;
    if (stars === 4) return `${Math.min(100, Math.max(10, (r - 3.8) * 40))}%`;
    if (stars === 3) return `${Math.min(100, Math.max(5, (5 - r) * 20))}%`;
    if (stars === 2) return `8%`;
    return `3%`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto bg-black/85 backdrop-blur-md">
      <div 
        className={`relative w-full max-w-4xl rounded-3xl overflow-hidden shadow-2xl transition-all border ${
          isDarkMode ? 'bg-[#07080c]/85 border-white/10 text-white backdrop-blur-xl' : 'bg-white/80 border-black/10 text-neutral-800 backdrop-blur-xl'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Banner with absolute close */}
        <div className="relative h-48 md:h-64 bg-neutral-900">
          <img 
            src={game.image} 
            alt={game.name} 
            className="w-full h-full object-cover filter brightness-[0.55]" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
          
          {/* Close button */}
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/60 hover:bg-emerald-500 hover:text-black text-white transition cursor-pointer"
            title="Close details"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Floating details wrapper */}
        <div className="relative px-6 md:px-10 pb-8 -mt-16 z-10">
          
          {/* Header Row: Thumbnail + Info */}
          <div className="flex flex-col sm:flex-row gap-5 items-start sm:items-end">
            <div className="w-28 h-28 rounded-2xl overflow-hidden shadow-xl border-4 border-neutral-950 bg-neutral-900 shrink-0">
              <img src={game.image} alt={game.name} className="w-full h-full object-cover" />
            </div>

            <div className="flex-1 space-y-1.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500 text-black shadow-neon-emerald">
                  {game.category}
                </span>
                <span className="flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-neutral-800 text-yellow-400">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  {game.rating}
                </span>
              </div>
              
              <h2 className="font-display font-black text-2xl sm:text-3xl tracking-tight text-white drop-shadow">
                {game.name}
              </h2>

              <div className="flex items-center gap-1.5 text-xs text-neutral-300">
                <Building2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Developer: <b className="text-white">{game.developer}</b></span>
              </div>
            </div>

            {/* Top Play/Favorite CTA */}
            <div className="flex items-center gap-2 w-full sm:w-auto shrink-0 pt-2 sm:pt-0">
              <button
                onClick={() => onPlayGame(game)}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-8 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm tracking-wide shadow-lg shadow-emerald-500/20 transform active:scale-95 transition cursor-pointer duration-300"
              >
                <Play className="w-4 h-4 fill-current" />
                Play Now
              </button>
              <button
                onClick={() => onToggleFavorite(game.id)}
                className={`p-3 rounded-xl transition ${
                  isFavorited 
                    ? 'bg-emerald-500 text-black fill-current' 
                    : 'bg-white/10 text-neutral-400 hover:text-emerald-400 hover:bg-white/20 border border-white/25'
                }`}
                title={isFavorited ? 'Remove wishlist' : 'Add wishlist'}
              >
                <Heart className="w-4.5 h-4.5" />
              </button>
            </div>
          </div>

          {/* Grid Layout: Left Description & Specs | Right Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
            
            {/* Left Col - 2/3 width */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* About section */}
              <div>
                <h4 className={`font-display font-bold text-base mb-3 ${isDarkMode ? 'text-white' : 'text-neutral-900'}`}>
                  About this game
                </h4>
                <p className={`text-sm leading-relaxed whitespace-pre-wrap font-sans ${
                  isDarkMode ? 'text-neutral-300' : 'text-neutral-600'
                }`}>
                  {game.description}
                  {"\n\n"}This legendary high-performance video game is polished for all standard browser runtimes. Challenge friends, set new high scores, and upgrade capabilities. Our portal verifies that this official URL contains active secure endpoints. Keep your layout optimized by bookmarking GameVerse.
                </p>
              </div>

              {/* Game Info Specs Grid */}
              <div className={`p-4 rounded-2xl grid grid-cols-2 sm:grid-cols-3 gap-4 border ${
                isDarkMode ? 'bg-white/5 border-white/10' : 'bg-black/5 border-black/10'
              }`}>
                <div>
                  <span className="block text-[10px] text-neutral-500 uppercase tracking-wide">Developer</span>
                  <span className="text-xs font-semibold">{game.developer}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-neutral-500 uppercase tracking-wide">Genre</span>
                  <span className="text-xs font-semibold">{game.category}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-neutral-500 uppercase tracking-wide">Installs</span>
                  <span className="text-xs font-semibold">10,000,000+ (MOCK)</span>
                </div>
                <div>
                  <span className="block text-[10px] text-neutral-500 uppercase tracking-wide">Requirements</span>
                  <span className="text-xs font-semibold">Standard Browser</span>
                </div>
                <div>
                  <span className="block text-[10px] text-neutral-500 uppercase tracking-wide">Rating</span>
                  <span className="text-xs font-semibold text-yellow-500">{game.rating} / 5.0</span>
                </div>
                <div>
                  <span className="block text-[10px] text-neutral-500 uppercase tracking-wide">Security</span>
                  <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                    <Download className="w-3.5 h-3.5" /> Verified
                  </span>
                </div>
              </div>

              {/* Security Banner */}
              <div className="flex items-center gap-3 p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0" />
                <p className="text-[11px] text-amber-400 leading-normal">
                  <b>Safety Notice:</b> GameVerse only indexes official and publicly available web URLs. Always proceed responsibly on third-party domains.
                </p>
              </div>

            </div>

            {/* Right Col - Rating Breakdown */}
            <div className="space-y-6">
              
              {/* Star Distribution Analysis */}
              <div className={`p-5 rounded-2xl border ${
                isDarkMode ? 'bg-white/5 border-white/10' : 'bg-black/5 border-black/10'
              }`}>
                <h4 className={`font-display font-bold text-base mb-4 ${isDarkMode ? 'text-white' : 'text-neutral-900'}`}>
                  Ratings & reviews
                </h4>
                
                <div className="flex items-center gap-4 mb-4">
                  <div className="text-center">
                    <span className="text-4xl font-extrabold tracking-tight">{game.rating}</span>
                    <span className="block text-[10px] text-neutral-500 mt-1">out of 5 stars</span>
                  </div>
                  
                  {/* Graphical Star Bars */}
                  <div className="flex-1 space-y-1">
                    {[5, 4, 3, 2, 1].map((stars) => (
                      <div key={stars} className="flex items-center gap-2">
                        <span className="text-[10px] font-semibold text-neutral-400 w-3 text-right">{stars}</span>
                        <div className="flex-1 h-2 rounded-full bg-neutral-800/40 overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-emerald-400 to-cyan-500 rounded-full"
                            style={{ width: getRatingBarWidth(stars) }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-[10px] text-neutral-400">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Calculated from Google Play community metrics.</span>
                </div>
              </div>

              {/* Similar Games recommendations */}
              <div>
                <h4 className={`font-display font-bold text-sm mb-3 ${isDarkMode ? 'text-white' : 'text-neutral-900'}`}>
                  You may also like
                </h4>
                
                <div className="space-y-2">
                  {similarGames.slice(0, 4).map((sg) => (
                    <div
                      key={sg.id}
                      onClick={() => onSelectSimilarGame(sg)}
                      className={`flex items-center gap-3 p-2 rounded-xl border transition cursor-pointer ${
                        isDarkMode 
                          ? 'bg-white/5 border-white/10 hover:bg-white/10' 
                          : 'bg-black/5 border-black/10 hover:bg-black/10'
                      }`}
                    >
                      <img src={sg.image} alt={sg.name} className="w-10 h-10 rounded-lg object-cover shrink-0" />
                      <div className="flex-1 min-w-0">
                        <h5 className="text-xs font-semibold truncate">{sg.name}</h5>
                        <p className="text-[10px] text-emerald-400 truncate">{sg.developer}</p>
                      </div>
                      <span className="text-xs font-semibold text-yellow-500 shrink-0 flex items-center gap-0.5 bg-yellow-500/5 px-1 py-0.5 rounded">
                        <Star className="w-3 h-3 fill-current" /> {sg.rating}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>

        </div>
      </div>
    </div>
  );
}
