import { useState, useEffect, useRef, useCallback } from 'react';
import { Game } from '../types';
import { 
  X, RotateCcw, Play, Pause, Volume2, VolumeX, ArrowLeft, ArrowRight, 
  ChevronUp, Shield, Sparkles, Trophy, Gamepad2, Coins, ArrowUpRight
} from 'lucide-react';

interface GamePlayerProps {
  game: Game;
  isDarkMode: boolean;
  onClose: () => void;
}

// Synthesized Retro Beep-Boop Sound Engine using Web Audio API
const playSound = (type: 'jump' | 'score' | 'hit' | 'win' | 'select' | 'lose') => {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    if (type === 'jump') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(150, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(420, ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);
      osc.start();
      osc.stop(ctx.currentTime + 0.12);
    } else if (type === 'score') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.08); // A5
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.22);
      osc.start();
      osc.stop(ctx.currentTime + 0.22);
    } else if (type === 'hit' || type === 'lose') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(60, ctx.currentTime + 0.35);
      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.35);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } else if (type === 'win') {
      osc.type = 'sine';
      const notes = [261.63, 329.63, 392.00, 523.25]; // C major chord arpeggio
      notes.forEach((freq, index) => {
        osc.frequency.setValueAtTime(freq, ctx.currentTime + index * 0.08);
      });
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.45);
      osc.start();
      osc.stop(ctx.currentTime + 0.45);
    } else if (type === 'select') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(330, ctx.currentTime);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.06);
      osc.start();
      osc.stop(ctx.currentTime + 0.06);
    }
  } catch (e) {
    // Autoplay or audio context blocked
  }
};

export default function GamePlayer({ game, isDarkMode, onClose }: GamePlayerProps) {
  // Determine game engine based on category or name
  const getGameEngineType = (): 'runner' | 'shooter' | 'racer' | 'snake' | 'breaker' | 'blackjack' | 'slots' | 'memory' => {
    const cat = game.category.toLowerCase();
    const id = game.id.toLowerCase();
    
    if (cat.includes('race') || cat.includes('car') || cat.includes('bike')) {
      return 'racer';
    } else if (cat.includes('shoot') || id.includes('fire') || id.includes('pubg') || id.includes('duty')) {
      return 'shooter';
    } else if (id.includes('subway') || id.includes('temple') || id.includes('climb')) {
      return 'runner';
    } else if (cat.includes('rummy') || cat.includes('card') || id.includes('blackjack')) {
      return 'blackjack';
    } else if (cat.includes('casino') || id.includes('slots') || id.includes('spin')) {
      return 'slots';
    } else if (cat.includes('ludo')) {
      return 'memory'; // Memory match themed as board/pieces
    } else if (cat.includes('puzzle') || cat.includes('strategy') || id.includes('candy') || id.includes('chess')) {
      return 'memory';
    } else if (id.includes('snake')) {
      return 'snake';
    } else {
      // Default fallbacks based on ID string parity
      const charSum = game.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
      const mod = charSum % 4;
      if (mod === 0) return 'runner';
      if (mod === 1) return 'snake';
      if (mod === 2) return 'breaker';
      return 'memory';
    }
  };

  const engineType = getGameEngineType();
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(() => {
    try {
      return Number(localStorage.getItem(`gameverse_high_${game.id}`)) || 0;
    } catch {
      return 0;
    }
  });
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Synced local states for Blackjack/Slots chip bankroll
  const [bankroll, setBankroll] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('gameverse_chips');
      return saved ? Number(saved) : 500;
    } catch {
      return 500;
    }
  });

  // Save bankroll
  useEffect(() => {
    localStorage.setItem('gameverse_chips', String(bankroll));
  }, [bankroll]);

  // Handle High Score Updates
  const updateHighScore = useCallback((newScore: number) => {
    if (newScore > highScore) {
      setHighScore(newScore);
      try {
        localStorage.setItem(`gameverse_high_${game.id}`, String(newScore));
      } catch (e) {
        // storage disabled
      }
      if (soundEnabled) playSound('win');
    }
  }, [highScore, game.id, soundEnabled]);

  const toggleSound = () => {
    const nextVal = !soundEnabled;
    setSoundEnabled(nextVal);
    if (nextVal) playSound('select');
  };

  const restartGame = () => {
    if (soundEnabled) playSound('select');
    setIsGameOver(false);
    setScore(0);
    setIsPlaying(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-0 md:p-4 bg-black/90 backdrop-blur-md overflow-hidden">
      <div className={`w-full h-full md:max-w-4xl md:h-[90vh] md:rounded-3xl flex flex-col border shadow-2xl overflow-hidden ${
        isDarkMode ? 'bg-[#0b0c10] border-white/10 text-white' : 'bg-neutral-900 border-black/20 text-white'
      }`}>
        {/* Header Controls */}
        <div className="px-4 py-3 flex items-center justify-between border-b border-white/10 shrink-0 bg-[#0d0e14]">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400 border border-emerald-500/20">
              <Gamepad2 className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-bold truncate max-w-[180px] sm:max-w-[300px] text-white">
                Playing: {game.name}
              </h3>
              <p className="text-[10px] text-emerald-400 font-semibold tracking-wider uppercase">
                {game.category} Engine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Volume */}
            <button 
              onClick={toggleSound}
              className={`p-2 rounded-lg transition hover:bg-white/10 ${soundEnabled ? 'text-emerald-400' : 'text-neutral-500'}`}
              title={soundEnabled ? 'Mute' : 'Unmute'}
            >
              {soundEnabled ? <Volume2 className="w-4.5 h-4.5" /> : <VolumeX className="w-4.5 h-4.5" />}
            </button>

            {/* Restart */}
            <button 
              onClick={restartGame}
              className="p-2 rounded-lg text-neutral-400 hover:text-white transition hover:bg-white/10"
              title="Restart Game"
            >
              <RotateCcw className="w-4.5 h-4.5" />
            </button>

            {/* Close */}
            <button 
              onClick={onClose}
              className="p-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500 hover:text-white transition cursor-pointer ml-1"
              title="Quit Game"
            >
              <X className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>

        {/* Dashboard Status Bar */}
        <div className="px-4 py-2 bg-black/40 border-b border-white/5 flex items-center justify-between text-xs font-mono text-neutral-400 shrink-0">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5 text-yellow-500" />
              Hi-Score: <b className="text-white">{highScore}</b>
            </span>
            {['blackjack', 'slots'].includes(engineType) && (
              <span className="flex items-center gap-1.5 text-emerald-400">
                <Coins className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400/10" />
                Chips: <b className="text-white">${bankroll}</b>
              </span>
            )}
          </div>
          <div>
            <span>Score: <b className="text-emerald-400 text-sm">{score}</b></span>
          </div>
        </div>

        {/* Actual Interactive Game Container */}
        <div className="flex-1 relative bg-[#07080c] flex items-center justify-center p-2 min-h-0 select-none">
          {engineType === 'runner' && (
            <RetroRunnerGame 
              isPlaying={isPlaying} 
              setIsPlaying={setIsPlaying}
              isGameOver={isGameOver}
              setIsGameOver={setIsGameOver}
              score={score}
              setScore={setScore}
              updateHighScore={updateHighScore}
              soundEnabled={soundEnabled}
            />
          )}
          {engineType === 'shooter' && (
            <GalaxyDefenderGame 
              isPlaying={isPlaying} 
              setIsPlaying={setIsPlaying}
              isGameOver={isGameOver}
              setIsGameOver={setIsGameOver}
              score={score}
              setScore={setScore}
              updateHighScore={updateHighScore}
              soundEnabled={soundEnabled}
            />
          )}
          {engineType === 'racer' && (
            <NeonRacerGame 
              isPlaying={isPlaying} 
              setIsPlaying={setIsPlaying}
              isGameOver={isGameOver}
              setIsGameOver={setIsGameOver}
              score={score}
              setScore={setScore}
              updateHighScore={updateHighScore}
              soundEnabled={soundEnabled}
            />
          )}
          {engineType === 'snake' && (
            <RetroSnakeGame 
              isPlaying={isPlaying} 
              setIsPlaying={setIsPlaying}
              isGameOver={isGameOver}
              setIsGameOver={setIsGameOver}
              score={score}
              setScore={setScore}
              updateHighScore={updateHighScore}
              soundEnabled={soundEnabled}
            />
          )}
          {engineType === 'breaker' && (
            <BrickBreakerGame 
              isPlaying={isPlaying} 
              setIsPlaying={setIsPlaying}
              isGameOver={isGameOver}
              setIsGameOver={setIsGameOver}
              score={score}
              setScore={setScore}
              updateHighScore={updateHighScore}
              soundEnabled={soundEnabled}
            />
          )}
          {engineType === 'blackjack' && (
            <BlackjackGame 
              isPlaying={isPlaying}
              setIsPlaying={setIsPlaying}
              score={score}
              setScore={setScore}
              updateHighScore={updateHighScore}
              bankroll={bankroll}
              setBankroll={setBankroll}
              soundEnabled={soundEnabled}
            />
          )}
          {engineType === 'slots' && (
            <NeonSlotsGame 
              score={score}
              setScore={setScore}
              updateHighScore={updateHighScore}
              bankroll={bankroll}
              setBankroll={setBankroll}
              soundEnabled={soundEnabled}
            />
          )}
          {engineType === 'memory' && (
            <MemoryMatchGame 
              isPlaying={isPlaying}
              isGameOver={isGameOver}
              setIsGameOver={setIsGameOver}
              score={score}
              setScore={setScore}
              updateHighScore={updateHighScore}
              soundEnabled={soundEnabled}
              restartTrigger={isGameOver ? 1 : 0}
            />
          )}

          {/* Pause / Game Over Screens */}
          {isGameOver && (
            <div className="absolute inset-0 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6 z-20">
              <div className="max-w-xs space-y-4 animate-fade-in">
                <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center text-red-500 border border-red-500/20 mx-auto">
                  <Shield className="w-8 h-8" />
                </div>
                <div>
                  <h2 className="font-display font-black text-2xl text-red-500 uppercase tracking-widest">
                    Game Over
                  </h2>
                  <p className="text-xs text-neutral-400 mt-1">
                    Your final score is {score}. Check out your High Score to see if you broke records!
                  </p>
                </div>
                <button
                  onClick={restartGame}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm tracking-wide transition cursor-pointer shadow-lg shadow-emerald-500/20"
                >
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </button>
                <button
                  onClick={onClose}
                  className="w-full py-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white font-semibold text-xs tracking-wide transition cursor-pointer"
                >
                  Back to Catalog
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer info/play tips */}
        <div className="px-4 py-2.5 bg-[#0d0e14] border-t border-white/10 text-center text-[10px] text-neutral-500 flex flex-col sm:flex-row items-center justify-between gap-1.5 shrink-0">
          <div className="flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-yellow-500" />
            <span>Fully compiled HTML5 web runner. Runs client-side sandboxed.</span>
          </div>
          <div className="flex items-center gap-3">
            <a 
              href={game.play_url} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-emerald-400 hover:underline flex items-center gap-0.5 font-bold cursor-pointer"
            >
              Open Official Live Site <ArrowUpRight className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ==========================================================================
   GAME ENGINE 1: RETRO RUNNER (Endless Jump game)
   ========================================================================== */
interface GameProps {
  isPlaying: boolean;
  setIsPlaying: (val: boolean) => void;
  isGameOver: boolean;
  setIsGameOver: (val: boolean) => void;
  score: number;
  setScore: (score: number | ((prev: number) => number)) => void;
  updateHighScore: (newScore: number) => void;
  soundEnabled: boolean;
}

function RetroRunnerGame({ isPlaying, setIsPlaying, isGameOver, setIsGameOver, score, setScore, updateHighScore, soundEnabled }: GameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameLoopRef = useRef<number | null>(null);

  // Gameplay state refs to avoid closure stalls in loop
  const playerY = useRef<number>(250);
  const playerVelocity = useRef<number>(0);
  const isJumping = useRef<boolean>(false);
  const obstacleX = useRef<number>(650);
  const obstacleSpeed = useRef<number>(4.5);
  const localScore = useRef<number>(0);

  const JUMP_FORCE = -8.5;
  const GRAVITY = 0.42;
  const GROUND_Y = 250;

  const triggerJump = useCallback(() => {
    if (!isJumping.current && !isGameOver && isPlaying) {
      playerVelocity.current = JUMP_FORCE;
      isJumping.current = true;
      if (soundEnabled) playSound('jump');
    }
  }, [isGameOver, isPlaying, soundEnabled]);

  // Handle keys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['Space', 'ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        triggerJump();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [triggerJump]);

  // Reset logic
  useEffect(() => {
    if (!isGameOver) {
      playerY.current = GROUND_Y;
      playerVelocity.current = 0;
      isJumping.current = false;
      obstacleX.current = 650;
      obstacleSpeed.current = 4.5;
      localScore.current = 0;
      setScore(0);
    }
  }, [isGameOver, setScore]);

  // Canvas Drawing Game Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      // Clear canvas
      ctx.fillStyle = '#07080c';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw Grid lines in BG
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.05)';
      ctx.lineWidth = 1;
      for (let i = 0; i < canvas.width; i += 40) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, canvas.height);
        ctx.stroke();
      }

      // Draw Ground
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, GROUND_Y + 30);
      ctx.lineTo(canvas.width, GROUND_Y + 30);
      ctx.stroke();

      // Update physics if playing
      if (isPlaying && !isGameOver) {
        // Player Gravity
        playerVelocity.current += GRAVITY;
        playerY.current += playerVelocity.current;

        if (playerY.current >= GROUND_Y) {
          playerY.current = GROUND_Y;
          playerVelocity.current = 0;
          isJumping.current = false;
        }

        // Obstacle Move
        obstacleX.current -= obstacleSpeed.current;
        if (obstacleX.current < -30) {
          obstacleX.current = canvas.width + 50 + Math.random() * 100;
          obstacleSpeed.current += 0.2; // Speed up
          localScore.current += 10;
          setScore(localScore.current);
          updateHighScore(localScore.current);
          if (soundEnabled) playSound('score');
        }

        // Collision Check
        const playerBox = { x: 80, y: playerY.current, w: 26, h: 30 };
        const obstacleBox = { x: obstacleX.current, y: GROUND_Y + 5, w: 20, h: 25 };

        if (
          playerBox.x < obstacleBox.x + obstacleBox.w &&
          playerBox.x + playerBox.w > obstacleBox.x &&
          playerBox.y < obstacleBox.y + obstacleBox.h &&
          playerBox.y + playerBox.h > obstacleBox.y
        ) {
          // Crash!
          setIsGameOver(true);
          setIsPlaying(false);
          if (soundEnabled) playSound('hit');
        }
      }

      // Draw Player (Glowing Emerald box)
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#10b981';
      ctx.fillStyle = '#10b981';
      ctx.fillRect(80, playerY.current, 26, 30);

      // Draw Runner Eye/Detial
      ctx.fillStyle = '#07080c';
      ctx.fillRect(94, playerY.current + 6, 8, 4);

      // Draw Obstacle (Glowing Crimson Spike)
      ctx.shadowColor = '#f43f5e';
      ctx.fillStyle = '#f43f5e';
      ctx.beginPath();
      ctx.moveTo(obstacleX.current, GROUND_Y + 30);
      ctx.lineTo(obstacleX.current + 12, GROUND_Y + 5);
      ctx.lineTo(obstacleX.current + 24, GROUND_Y + 30);
      ctx.closePath();
      ctx.fill();

      // Reset shadows
      ctx.shadowBlur = 0;

      // Draw instructions
      if (!isPlaying && !isGameOver) {
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('GAME PAUSED', canvas.width / 2, canvas.height / 2 - 15);
        ctx.font = '12px monospace';
        ctx.fillStyle = '#10b981';
        ctx.fillText('Tap Jump button or Space to Start', canvas.width / 2, canvas.height / 2 + 15);
      }

      gameLoopRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    };
  }, [isPlaying, isGameOver, setScore, updateHighScore, soundEnabled]);

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col gap-4 items-center">
      <div className="relative w-full aspect-[3/2] bg-black rounded-2xl overflow-hidden border border-white/10">
        <canvas 
          ref={canvasRef} 
          width={480} 
          height={320} 
          className="w-full h-full block"
          onClick={triggerJump}
        />
      </div>

      <div className="flex gap-4 w-full shrink-0">
        <button
          onClick={triggerJump}
          className="flex-1 py-4 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold rounded-xl shadow-lg active:scale-98 transition flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <ChevronUp className="w-6 h-6 stroke-[3]" />
          JUMP (Space)
        </button>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          disabled={isGameOver}
          className="px-5 bg-white/10 hover:bg-white/15 text-white border border-white/15 rounded-xl flex items-center justify-center cursor-pointer disabled:opacity-40"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
        </button>
      </div>
    </div>
  );
}

/* ==========================================================================
   GAME ENGINE 2: GALAXY DEFENDER (Space Shooter game)
   ========================================================================== */
function GalaxyDefenderGame({ isPlaying, setIsPlaying, isGameOver, setIsGameOver, score, setScore, updateHighScore, soundEnabled }: GameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameLoopRef = useRef<number | null>(null);

  // Space Invaders states
  const playerX = useRef<number>(240);
  const bullets = useRef<Array<{x: number, y: number}>>([]);
  const aliens = useRef<Array<{x: number, y: number, id: number}>>([]);
  const alienDirection = useRef<number>(1);
  const alienSpeed = useRef<number>(1.2);
  const lastShot = useRef<number>(0);
  const localScore = useRef<number>(0);

  // Commands
  const moveLeft = useRef<boolean>(false);
  const moveRight = useRef<boolean>(false);

  const initAliens = () => {
    const list = [];
    let id = 0;
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 8; c++) {
        list.push({ x: 40 + c * 48, y: 35 + r * 30, id: id++ });
      }
    }
    aliens.current = list;
  };

  const triggerShoot = useCallback(() => {
    if (!isGameOver && isPlaying) {
      const now = Date.now();
      if (now - lastShot.current > 350) {
        bullets.current.push({ x: playerX.current + 11, y: 280 });
        lastShot.current = now;
        if (soundEnabled) playSound('jump');
      }
    }
  }, [isGameOver, isPlaying, soundEnabled]);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') moveLeft.current = true;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') moveRight.current = true;
      if (e.code === 'Space') {
        e.preventDefault();
        triggerShoot();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') moveLeft.current = false;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') moveRight.current = false;
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [triggerShoot]);

  // Reset
  useEffect(() => {
    if (!isGameOver) {
      playerX.current = 240;
      bullets.current = [];
      initAliens();
      alienDirection.current = 1;
      alienSpeed.current = 1.2;
      localScore.current = 0;
      setScore(0);
    }
  }, [isGameOver, setScore]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      ctx.fillStyle = '#07080c';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw faint star field
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      for (let i = 0; i < 20; i++) {
        const x = (i * 73) % canvas.width;
        const y = (i * 123) % canvas.height;
        ctx.fillRect(x, y, 1.5, 1.5);
      }

      if (isPlaying && !isGameOver) {
        // Player movement
        if (moveLeft.current) playerX.current = Math.max(10, playerX.current - 4.5);
        if (moveRight.current) playerX.current = Math.min(canvas.width - 34, playerX.current + 4.5);

        // Bullets update
        bullets.current = bullets.current
          .map(b => ({ ...b, y: b.y - 6 }))
          .filter(b => b.y > 0);

        // Aliens update
        let shiftDown = false;
        aliens.current.forEach(a => {
          a.x += alienSpeed.current * alienDirection.current;
          if (a.x > canvas.width - 30 || a.x < 10) {
            shiftDown = true;
          }
        });

        if (shiftDown) {
          alienDirection.current *= -1;
          aliens.current.forEach(a => {
            a.y += 12;
            if (a.y >= 270) {
              setIsGameOver(true);
              setIsPlaying(false);
              if (soundEnabled) playSound('hit');
            }
          });
        }

        // Collision Check
        bullets.current.forEach((b, bIdx) => {
          aliens.current.forEach((a, aIdx) => {
            if (b.x >= a.x && b.x <= a.x + 22 && b.y >= a.y && b.y <= a.y + 18) {
              // Destroy alien
              aliens.current.splice(aIdx, 1);
              bullets.current.splice(bIdx, 1);
              localScore.current += 20;
              setScore(localScore.current);
              updateHighScore(localScore.current);
              if (soundEnabled) playSound('score');

              // Respawn if cleared
              if (aliens.current.length === 0) {
                alienSpeed.current += 0.3;
                initAliens();
              }
            }
          });
        });
      }

      // Draw Player Ship
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#06b6d4';
      ctx.fillStyle = '#06b6d4';
      ctx.beginPath();
      ctx.moveTo(playerX.current + 12, 280);
      ctx.lineTo(playerX.current, 298);
      ctx.lineTo(playerX.current + 24, 298);
      ctx.closePath();
      ctx.fill();

      // Ship turret detail
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(playerX.current + 10, 276, 4, 6);

      // Draw bullets
      ctx.shadowColor = '#ff007f';
      ctx.fillStyle = '#ff007f';
      bullets.current.forEach(b => {
        ctx.fillRect(b.x, b.y, 3, 8);
      });

      // Draw aliens
      ctx.shadowColor = '#10b981';
      ctx.fillStyle = '#10b981';
      aliens.current.forEach(a => {
        ctx.fillRect(a.x, a.y, 22, 14);
        ctx.fillStyle = '#000';
        ctx.fillRect(a.x + 4, a.y + 4, 3, 3);
        ctx.fillRect(a.x + 15, a.y + 4, 3, 3);
        ctx.fillStyle = '#10b981';
      });

      ctx.shadowBlur = 0;

      // Draw Instructions overlay
      if (!isPlaying && !isGameOver) {
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('GAME PAUSED', canvas.width / 2, canvas.height / 2 - 15);
        ctx.font = '12px monospace';
        ctx.fillStyle = '#06b6d4';
        ctx.fillText('Press Shoot or Space to Start', canvas.width / 2, canvas.height / 2 + 15);
      }

      gameLoopRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    };
  }, [isPlaying, isGameOver, setScore, updateHighScore, soundEnabled]);

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col gap-4 items-center">
      <div className="relative w-full aspect-[3/2] bg-black rounded-2xl overflow-hidden border border-white/10">
        <canvas ref={canvasRef} width={480} height={320} className="w-full h-full block" />
      </div>

      <div className="flex gap-2 w-full shrink-0">
        <button
          onMouseDown={() => { moveLeft.current = true; }}
          onMouseUp={() => { moveLeft.current = false; }}
          onMouseLeave={() => { moveLeft.current = false; }}
          onTouchStart={() => { moveLeft.current = true; }}
          onTouchEnd={() => { moveLeft.current = false; }}
          className="flex-1 py-3.5 bg-white/5 hover:bg-white/10 text-white rounded-xl flex items-center justify-center border border-white/10 active:scale-95 transition cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <button
          onClick={triggerShoot}
          className="flex-[2] py-3.5 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold rounded-xl shadow-md active:scale-95 transition cursor-pointer"
        >
          FIRE LASER
        </button>
        <button
          onMouseDown={() => { moveRight.current = true; }}
          onMouseUp={() => { moveRight.current = false; }}
          onMouseLeave={() => { moveRight.current = false; }}
          onTouchStart={() => { moveRight.current = true; }}
          onTouchEnd={() => { moveRight.current = false; }}
          className="flex-1 py-3.5 bg-white/5 hover:bg-white/10 text-white rounded-xl flex items-center justify-center border border-white/10 active:scale-95 transition cursor-pointer"
        >
          <ArrowRight className="w-5 h-5" />
        </button>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          disabled={isGameOver}
          className="px-4 bg-white/10 hover:bg-white/15 text-white border border-white/15 rounded-xl flex items-center justify-center cursor-pointer"
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
        </button>
      </div>
    </div>
  );
}

/* ==========================================================================
   GAME ENGINE 3: NEON RACER (3-Lane Highway dodge racer)
   ========================================================================== */
function NeonRacerGame({ isPlaying, setIsPlaying, isGameOver, setIsGameOver, score, setScore, updateHighScore, soundEnabled }: GameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameLoopRef = useRef<number | null>(null);

  // Racing State
  const playerLane = useRef<number>(1); // 0, 1, 2
  const targetLaneX = useRef<number>(240);
  const playerX = useRef<number>(240);
  const enemies = useRef<Array<{lane: number, y: number, color: string, speed: number}>>([]);
  const roadY = useRef<number>(0);
  const speed = useRef<number>(6);
  const localScore = useRef<number>(0);

  const LANES_X = [120, 240, 360];

  const changeLane = (dir: 'left' | 'right') => {
    if (isGameOver || !isPlaying) return;
    if (dir === 'left' && playerLane.current > 0) {
      playerLane.current -= 1;
      if (soundEnabled) playSound('select');
    } else if (dir === 'right' && playerLane.current < 2) {
      playerLane.current += 1;
      if (soundEnabled) playSound('select');
    }
    targetLaneX.current = LANES_X[playerLane.current];
  };

  // Keyboard
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') changeLane('left');
      if (e.code === 'ArrowRight' || e.code === 'KeyD') changeLane('right');
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isGameOver, isPlaying]);

  // Reset
  useEffect(() => {
    if (!isGameOver) {
      playerLane.current = 1;
      playerX.current = LANES_X[1];
      targetLaneX.current = LANES_X[1];
      enemies.current = [];
      speed.current = 6;
      localScore.current = 0;
      setScore(0);
    }
  }, [isGameOver, setScore]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      ctx.fillStyle = '#07080c';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw lanes bounds
      ctx.strokeStyle = 'rgba(255,255,255,0.04)';
      ctx.lineWidth = 4;
      ctx.strokeRect(60, -10, 360, canvas.height + 20);

      // Lane divider lines (dashed)
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.setLineDash([20, 20]);
      ctx.lineDashOffset = -roadY.current;

      ctx.beginPath();
      ctx.moveTo(180, 0); ctx.lineTo(180, canvas.height);
      ctx.moveTo(300, 0); ctx.lineTo(300, canvas.height);
      ctx.stroke();
      ctx.setLineDash([]); // Reset dash

      if (isPlaying && !isGameOver) {
        // Move road
        roadY.current = (roadY.current + speed.current) % 40;

        // Animate player towards target lane center
        playerX.current += (targetLaneX.current - playerX.current) * 0.25;

        // Update enemies
        enemies.current.forEach(e => {
          e.y += e.speed;
        });

        // Spawn enemy
        if (enemies.current.length === 0 || enemies.current[enemies.current.length - 1].y > 150) {
          const possibleLanes = [0, 1, 2];
          const chosenLane = possibleLanes[Math.floor(Math.random() * possibleLanes.length)];
          const colors = ['#f43f5e', '#a855f7', '#3b82f6', '#eab308'];
          const color = colors[Math.floor(Math.random() * colors.length)];
          enemies.current.push({
            lane: chosenLane,
            y: -60,
            color,
            speed: speed.current + (Math.random() * 2 - 0.5)
          });
        }

        // Clean out of bounds enemies
        const beforeLen = enemies.current.length;
        enemies.current = enemies.current.filter(e => e.y < canvas.height + 20);
        if (enemies.current.length < beforeLen) {
          localScore.current += 15;
          setScore(localScore.current);
          updateHighScore(localScore.current);
          if (soundEnabled) playSound('score');
          if (localScore.current % 150 === 0) {
            speed.current += 0.5; // Accelerate!
          }
        }

        // Check crash collisions
        enemies.current.forEach(e => {
          const enemyX = LANES_X[e.lane];
          // Simple box collision
          if (
            Math.abs(playerX.current - enemyX) < 25 &&
            e.y > 230 && e.y < 290
          ) {
            setIsGameOver(true);
            setIsPlaying(false);
            if (soundEnabled) playSound('hit');
          }
        });
      }

      // Draw Player Car (Emerald glow racer)
      ctx.shadowBlur = 12;
      ctx.shadowColor = '#10b981';
      ctx.fillStyle = '#10b981';
      // Main chassis
      ctx.fillRect(playerX.current - 14, 250, 28, 40);
      // Windshield
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(playerX.current - 10, 256, 20, 10);
      // Wheels
      ctx.fillStyle = '#000';
      ctx.fillRect(playerX.current - 17, 254, 3, 8);
      ctx.fillRect(playerX.current + 14, 254, 3, 8);
      ctx.fillRect(playerX.current - 17, 276, 3, 8);
      ctx.fillRect(playerX.current + 14, 276, 3, 8);

      // Draw Enemy Cars
      enemies.current.forEach(e => {
        const eX = LANES_X[e.lane];
        ctx.shadowColor = e.color;
        ctx.fillStyle = e.color;
        // Chassis
        ctx.fillRect(eX - 14, e.y, 28, 40);
        // Windshield
        ctx.fillStyle = '#000000';
        ctx.fillRect(eX - 10, e.y + 24, 20, 8);
      });

      ctx.shadowBlur = 0;

      // Draw instructions
      if (!isPlaying && !isGameOver) {
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('GAME PAUSED', canvas.width / 2, canvas.height / 2 - 15);
        ctx.font = '12px monospace';
        ctx.fillStyle = '#10b981';
        ctx.fillText('Tap Arrows to switch lanes', canvas.width / 2, canvas.height / 2 + 15);
      }

      gameLoopRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    };
  }, [isPlaying, isGameOver, setScore, updateHighScore, soundEnabled]);

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col gap-4 items-center">
      <div className="relative w-full aspect-[3/2] bg-[#07080c] rounded-2xl overflow-hidden border border-white/10">
        <canvas ref={canvasRef} width={480} height={320} className="w-full h-full block" />
      </div>

      <div className="flex gap-3 w-full shrink-0">
        <button
          onClick={() => changeLane('left')}
          className="flex-1 py-4 bg-white/5 hover:bg-white/10 text-white rounded-xl flex items-center justify-center border border-white/10 active:scale-95 transition cursor-pointer font-bold gap-2"
        >
          <ArrowLeft className="w-5 h-5" />
          Lane Left
        </button>
        <button
          onClick={() => changeLane('right')}
          className="flex-1 py-4 bg-white/5 hover:bg-white/10 text-white rounded-xl flex items-center justify-center border border-white/10 active:scale-95 transition cursor-pointer font-bold gap-2"
        >
          Lane Right
          <ArrowRight className="w-5 h-5" />
        </button>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          disabled={isGameOver}
          className="px-5 bg-white/10 hover:bg-white/15 text-white border border-white/15 rounded-xl flex items-center justify-center cursor-pointer"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
        </button>
      </div>
    </div>
  );
}

/* ==========================================================================
   GAME ENGINE 4: RETRO SNAKE (Classic Grid Snake)
   ========================================================================== */
function RetroSnakeGame({ isPlaying, setIsPlaying, isGameOver, setIsGameOver, score, setScore, updateHighScore, soundEnabled }: GameProps) {
  const GRID_SIZE = 16;
  const [snake, setSnake] = useState<Array<{x: number, y: number}>>([
    { x: 8, y: 8 },
    { x: 7, y: 8 },
    { x: 6, y: 8 }
  ]);
  const [food, setFood] = useState<{x: number, y: number}>({ x: 12, y: 8 });
  const direction = useRef<{x: number, y: number}>({ x: 1, y: 0 });
  const pendingDirection = useRef<{x: number, y: number}>({ x: 1, y: 0 });

  const setDir = (x: number, y: number) => {
    if (isGameOver || !isPlaying) return;
    // Prevent 180 degree instant flips
    if (x !== 0 && direction.current.x !== 0) return;
    if (y !== 0 && direction.current.y !== 0) return;
    pendingDirection.current = { x, y };
    if (soundEnabled) playSound('select');
  };

  // Keyboard Controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowUp', 'KeyW'].includes(e.code)) { e.preventDefault(); setDir(0, -1); }
      if (['ArrowDown', 'KeyS'].includes(e.code)) { e.preventDefault(); setDir(0, 1); }
      if (['ArrowLeft', 'KeyA'].includes(e.code)) { e.preventDefault(); setDir(-1, 0); }
      if (['ArrowRight', 'KeyD'].includes(e.code)) { e.preventDefault(); setDir(1, 0); }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isGameOver]);

  // Reset
  useEffect(() => {
    if (!isGameOver) {
      setSnake([
        { x: 8, y: 8 },
        { x: 7, y: 8 },
        { x: 6, y: 8 }
      ]);
      setFood({ x: 12, y: 8 });
      direction.current = { x: 1, y: 0 };
      pendingDirection.current = { x: 1, y: 0 };
      setScore(0);
    }
  }, [isGameOver, setScore]);

  // Game Loop interval
  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    const interval = setInterval(() => {
      setSnake((prevSnake) => {
        direction.current = pendingDirection.current;
        const head = prevSnake[0];
        const nextHead = {
          x: head.x + direction.current.x,
          y: head.y + direction.current.y
        };

        // Self Wall collision check
        if (
          nextHead.x < 0 || nextHead.x >= GRID_SIZE ||
          nextHead.y < 0 || nextHead.y >= GRID_SIZE
        ) {
          setIsGameOver(true);
          setIsPlaying(false);
          if (soundEnabled) playSound('hit');
          return prevSnake;
        }

        // Snake segments collision
        for (const segment of prevSnake) {
          if (segment.x === nextHead.x && segment.y === nextHead.y) {
            setIsGameOver(true);
            setIsPlaying(false);
            if (soundEnabled) playSound('hit');
            return prevSnake;
          }
        }

        const nextSnake = [nextHead, ...prevSnake];

        // Eat Food
        if (nextHead.x === food.x && nextHead.y === food.y) {
          setScore((s) => {
            const nextScore = s + 10;
            updateHighScore(nextScore);
            return nextScore;
          });
          if (soundEnabled) playSound('score');

          // Spawn next food
          let newFood;
          while (true) {
            newFood = {
              x: Math.floor(Math.random() * GRID_SIZE),
              y: Math.floor(Math.random() * GRID_SIZE)
            };
            // Check if food on snake
            const onSnake = nextSnake.some(s => s.x === newFood.x && s.y === newFood.y);
            if (!onSnake) break;
          }
          setFood(newFood);
        } else {
          nextSnake.pop(); // Remove tail
        }

        return nextSnake;
      });
    }, 150);

    return () => clearInterval(interval);
  }, [isPlaying, isGameOver, food, setScore, updateHighScore, soundEnabled]);

  return (
    <div className="w-full max-w-sm mx-auto flex flex-col gap-3 items-center">
      {/* Game Board Grid representation */}
      <div className="relative w-full aspect-square bg-[#07080c] rounded-2xl overflow-hidden border border-white/10 p-1 flex flex-wrap">
        {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, idx) => {
          const x = idx % GRID_SIZE;
          const y = Math.floor(idx / GRID_SIZE);
          
          const isHead = snake[0].x === x && snake[0].y === y;
          const isBody = snake.slice(1).some(segment => segment.x === x && segment.y === y);
          const isFood = food.x === x && food.y === y;

          return (
            <div 
              key={idx} 
              style={{ width: `${100 / GRID_SIZE}%`, height: `${100 / GRID_SIZE}%` }}
              className="p-0.5"
            >
              <div className={`w-full h-full rounded-sm transition-all duration-100 ${
                isHead 
                  ? 'bg-emerald-400 shadow-lg shadow-emerald-500/50' 
                  : isBody 
                    ? 'bg-emerald-600/70' 
                    : isFood 
                      ? 'bg-red-500 shadow-md shadow-red-500/50 animate-pulse' 
                      : 'bg-white/[0.02]'
              }`} />
            </div>
          );
        })}
      </div>

      {/* D-Pad Buttons for Touch controls */}
      <div className="grid grid-cols-3 gap-2 w-full max-w-[180px] shrink-0">
        <div />
        <button 
          onClick={() => setDir(0, -1)}
          className="p-3.5 bg-white/5 border border-white/10 rounded-xl text-white flex justify-center active:scale-90 transition cursor-pointer"
        >
          ▲
        </button>
        <div />
        <button 
          onClick={() => setDir(-1, 0)}
          className="p-3.5 bg-white/5 border border-white/10 rounded-xl text-white flex justify-center active:scale-90 transition cursor-pointer"
        >
          ◀
        </button>
        <button 
          onClick={() => setIsPlaying(!isPlaying)}
          disabled={isGameOver}
          className="p-3.5 bg-white/10 border border-white/15 rounded-xl text-emerald-400 flex justify-center active:scale-90 transition"
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
        </button>
        <button 
          onClick={() => setDir(1, 0)}
          className="p-3.5 bg-white/5 border border-white/10 rounded-xl text-white flex justify-center active:scale-90 transition cursor-pointer"
        >
          ▶
        </button>
        <div />
        <button 
          onClick={() => setDir(0, 1)}
          className="p-3.5 bg-white/5 border border-white/10 rounded-xl text-white flex justify-center active:scale-90 transition cursor-pointer"
        >
          ▼
        </button>
        <div />
      </div>
    </div>
  );
}

/* ==========================================================================
   GAME ENGINE 5: BRICK BREAKER (Retro Breakout style ball arcade)
   ========================================================================== */
function BrickBreakerGame({ isPlaying, setIsPlaying, isGameOver, setIsGameOver, score, setScore, updateHighScore, soundEnabled }: GameProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameLoopRef = useRef<number | null>(null);

  // Ball & Paddle states
  const paddleX = useRef<number>(200);
  const ball = useRef<{x: number, y: number, dx: number, dy: number, radius: number}>({
    x: 240,
    y: 200,
    dx: 3,
    dy: -3,
    radius: 5
  });
  const bricks = useRef<Array<{x: number, y: number, w: number, h: number, active: boolean, color: string}>>([]);
  const localScore = useRef<number>(0);

  // Mouse / Slide Controls
  const moveLeft = useRef<boolean>(false);
  const moveRight = useRef<boolean>(false);

  const BRICK_ROWS = 4;
  const BRICK_COLS = 7;
  const PADDLE_WIDTH = 75;

  const initBricks = () => {
    const list = [];
    const colors = ['#f43f5e', '#a855f7', '#06b6d4', '#10b981'];
    const brickW = 52;
    const brickH = 15;
    for (let r = 0; r < BRICK_ROWS; r++) {
      for (let c = 0; c < BRICK_COLS; c++) {
        list.push({
          x: 25 + c * 62,
          y: 35 + r * 22,
          w: brickW,
          h: brickH,
          active: true,
          color: colors[r % colors.length]
        });
      }
    }
    bricks.current = list;
  };

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') moveLeft.current = true;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') moveRight.current = true;
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'ArrowLeft' || e.code === 'KeyA') moveLeft.current = false;
      if (e.code === 'ArrowRight' || e.code === 'KeyD') moveRight.current = false;
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Reset
  useEffect(() => {
    if (!isGameOver) {
      paddleX.current = 200;
      ball.current = {
        x: 240,
        y: 200,
        dx: 3 * (Math.random() > 0.5 ? 1 : -1),
        dy: -3.2,
        radius: 6
      };
      initBricks();
      localScore.current = 0;
      setScore(0);
    }
  }, [isGameOver, setScore]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const render = () => {
      ctx.fillStyle = '#07080c';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (isPlaying && !isGameOver) {
        // Move Paddle
        if (moveLeft.current) paddleX.current = Math.max(10, paddleX.current - 5);
        if (moveRight.current) paddleX.current = Math.min(canvas.width - PADDLE_WIDTH - 10, paddleX.current + 5);

        // Move Ball
        const b = ball.current;
        b.x += b.dx;
        b.y += b.dy;

        // Wall collisions
        if (b.x + b.radius > canvas.width || b.x - b.radius < 0) {
          b.dx = -b.dx;
          if (soundEnabled) playSound('select');
        }
        if (b.y - b.radius < 0) {
          b.dy = -b.dy;
          if (soundEnabled) playSound('select');
        }

        // Paddle bounce collision
        if (
          b.y + b.radius >= 290 &&
          b.x >= paddleX.current &&
          b.x <= paddleX.current + PADDLE_WIDTH
        ) {
          b.dy = -Math.abs(b.dy);
          // Angle modifier
          const hitPos = (b.x - paddleX.current) / PADDLE_WIDTH;
          b.dx = 6 * (hitPos - 0.5);
          if (soundEnabled) playSound('jump');
        }

        // Floor death collision
        if (b.y + b.radius > canvas.height) {
          setIsGameOver(true);
          setIsPlaying(false);
          if (soundEnabled) playSound('hit');
        }

        // Brick collisions
        bricks.current.forEach(br => {
          if (br.active) {
            if (
              b.x + b.radius >= br.x &&
              b.x - b.radius <= br.x + br.w &&
              b.y + b.radius >= br.y &&
              b.y - b.radius <= br.y + br.h
            ) {
              br.active = false;
              b.dy = -b.dy;
              localScore.current += 10;
              setScore(localScore.current);
              updateHighScore(localScore.current);
              if (soundEnabled) playSound('score');

              // Respawn if cleared
              if (bricks.current.every(x => !x.active)) {
                initBricks();
                b.dy = -Math.abs(b.dy) - 0.3; // slightly harder
              }
            }
          }
        });
      }

      // Draw bricks
      ctx.shadowBlur = 4;
      bricks.current.forEach(br => {
        if (br.active) {
          ctx.shadowColor = br.color;
          ctx.fillStyle = br.color;
          ctx.fillRect(br.x, br.y, br.w, br.h);
        }
      });

      // Draw Paddle
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#10b981';
      ctx.fillStyle = '#10b981';
      ctx.fillRect(paddleX.current, 290, PADDLE_WIDTH, 10);

      // Draw Ball
      ctx.shadowColor = '#fff';
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(ball.current.x, ball.current.y, ball.current.radius, 0, Math.PI * 2);
      ctx.fill();

      ctx.shadowBlur = 0;

      // Draw instructions
      if (!isPlaying && !isGameOver) {
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('GAME PAUSED', canvas.width / 2, canvas.height / 2 - 15);
        ctx.font = '12px monospace';
        ctx.fillStyle = '#10b981';
        ctx.fillText('Move paddle with keyboard arrows', canvas.width / 2, canvas.height / 2 + 15);
      }

      gameLoopRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
    };
  }, [isPlaying, isGameOver, setScore, updateHighScore, soundEnabled]);

  return (
    <div className="w-full max-w-lg mx-auto flex flex-col gap-4 items-center animate-fade-in">
      <div className="relative w-full aspect-[3/2] bg-[#07080c] rounded-2xl overflow-hidden border border-white/10">
        <canvas ref={canvasRef} width={480} height={320} className="w-full h-full block" />
      </div>

      <div className="flex gap-4 w-full shrink-0">
        <button
          onMouseDown={() => { moveLeft.current = true; }}
          onMouseUp={() => { moveLeft.current = false; }}
          onMouseLeave={() => { moveLeft.current = false; }}
          onTouchStart={() => { moveLeft.current = true; }}
          onTouchEnd={() => { moveLeft.current = false; }}
          className="flex-1 py-4 bg-white/5 hover:bg-white/10 text-white rounded-xl flex items-center justify-center border border-white/10 active:scale-95 transition cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
          Move Left
        </button>
        <button
          onMouseDown={() => { moveRight.current = true; }}
          onMouseUp={() => { moveRight.current = false; }}
          onMouseLeave={() => { moveRight.current = false; }}
          onTouchStart={() => { moveRight.current = true; }}
          onTouchEnd={() => { moveRight.current = false; }}
          className="flex-1 py-4 bg-white/5 hover:bg-white/10 text-white rounded-xl flex items-center justify-center border border-white/10 active:scale-95 transition cursor-pointer"
        >
          Move Right
          <ArrowRight className="w-5 h-5" />
        </button>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          disabled={isGameOver}
          className="px-5 bg-white/10 hover:bg-white/15 text-white border border-white/15 rounded-xl flex items-center justify-center cursor-pointer"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
        </button>
      </div>
    </div>
  );
}

/* ==========================================================================
   GAME ENGINE 6: BLACKJACK 21
   ========================================================================== */
interface Card {
  suit: '♠' | '♥' | '♦' | '♣';
  value: string;
  score: number;
}

interface CardGameProps {
  isPlaying: boolean;
  setIsPlaying: (val: boolean) => void;
  score: number;
  setScore: (score: number) => void;
  updateHighScore: (newScore: number) => void;
  bankroll: number;
  setBankroll: (val: number | ((prev: number) => number)) => void;
  soundEnabled: boolean;
}

function BlackjackGame({ isPlaying, setIsPlaying, score, setScore, updateHighScore, bankroll, setBankroll, soundEnabled }: CardGameProps) {
  const [deck, setDeck] = useState<Card[]>([]);
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [bet, setBet] = useState<number>(20);
  const [gameStage, setGameStage] = useState<'betting' | 'playing' | 'dealerTurn' | 'result'>('betting');
  const [outcomeMessage, setOutcomeMessage] = useState<string>('');

  const generateDeck = (): Card[] => {
    const suits: Array<'♠' | '♥' | '♦' | '♣'> = ['♠', '♥', '♦', '♣'];
    const values = [
      { v: '2', s: 2 }, { v: '3', s: 3 }, { v: '4', s: 4 }, { v: '5', s: 5 },
      { v: '6', s: 6 }, { v: '7', s: 7 }, { v: '8', s: 8 }, { v: '9', s: 9 },
      { v: '10', s: 10 }, { v: 'J', s: 10 }, { v: 'Q', s: 10 }, { v: 'K', s: 10 },
      { v: 'A', s: 11 }
    ];
    const newDeck: Card[] = [];
    suits.forEach(suit => {
      values.forEach(item => {
        newDeck.push({ suit, value: item.v, score: item.s });
      });
    });
    // Shuffle
    return newDeck.sort(() => Math.random() - 0.5);
  };

  const getHandTotal = (hand: Card[]): number => {
    let total = hand.reduce((sum, card) => sum + card.score, 0);
    // Adjust Aces if buster
    let aces = hand.filter(c => c.value === 'A').length;
    while (total > 21 && aces > 0) {
      total -= 10;
      aces -= 1;
    }
    return total;
  };

  const startNewRound = () => {
    if (bankroll < bet) {
      alert("Insufficient chips! Resetting bankroll to $500.");
      setBankroll(500);
      return;
    }
    if (soundEnabled) playSound('select');
    setBankroll(prev => prev - bet);

    const shuff = generateDeck();
    const pHand = [shuff[0], shuff[2]];
    const dHand = [shuff[1], shuff[3]];

    setPlayerHand(pHand);
    setDealerHand(dHand);
    setDeck(shuff.slice(4));

    const pTotal = getHandTotal(pHand);
    if (pTotal === 21) {
      // Blackjack win instantly!
      setGameStage('result');
      setOutcomeMessage('Blackjack! You win 3:2 payout!');
      setBankroll(prev => prev + Math.floor(bet * 2.5));
      setScore(score + 100);
      updateHighScore(score + 100);
      if (soundEnabled) playSound('win');
    } else {
      setGameStage('playing');
    }
  };

  const handleHit = () => {
    if (gameStage !== 'playing') return;
    const nextCard = deck[0];
    const nextHand = [...playerHand, nextCard];
    setPlayerHand(nextHand);
    setDeck(deck.slice(1));
    if (soundEnabled) playSound('jump');

    if (getHandTotal(nextHand) > 21) {
      setGameStage('result');
      setOutcomeMessage('Bust! Dealer wins.');
      setScore(Math.max(0, score - 20));
      if (soundEnabled) playSound('hit');
    }
  };

  const handleStand = () => {
    if (gameStage !== 'playing') return;
    setGameStage('dealerTurn');
    if (soundEnabled) playSound('select');

    // Simple dealer AI loop
    let currentDeck = [...deck];
    let currentDealerHand = [...dealerHand];

    while (getHandTotal(currentDealerHand) < 17) {
      currentDealerHand.push(currentDeck[0]);
      currentDeck = currentDeck.slice(1);
    }

    setDealerHand(currentDealerHand);
    setDeck(currentDeck);

    const pTotal = getHandTotal(playerHand);
    const dTotal = getHandTotal(currentDealerHand);

    setGameStage('result');

    if (dTotal > 21) {
      setOutcomeMessage('Dealer busts! You win!');
      setBankroll(prev => prev + bet * 2);
      setScore(score + 50);
      updateHighScore(score + 50);
      if (soundEnabled) playSound('win');
    } else if (pTotal > dTotal) {
      setOutcomeMessage('You win!');
      setBankroll(prev => prev + bet * 2);
      setScore(score + 40);
      updateHighScore(score + 40);
      if (soundEnabled) playSound('win');
    } else if (pTotal < dTotal) {
      setOutcomeMessage('Dealer wins.');
      setScore(Math.max(0, score - 15));
      if (soundEnabled) playSound('lose');
    } else {
      setOutcomeMessage("It's a push (tie).");
      setBankroll(prev => prev + bet);
      if (soundEnabled) playSound('select');
    }
  };

  return (
    <div className="w-full max-w-md mx-auto p-4 flex flex-col gap-6 items-center">
      
      {/* Casino Velvet Table layout */}
      <div className="w-full aspect-[4/3] bg-emerald-800 rounded-2xl border-4 border-amber-950 p-4 shadow-2xl flex flex-col justify-between relative overflow-hidden">
        {/* Subtle wood felt details */}
        <div className="absolute inset-0 border border-emerald-900/60 rounded-xl" />
        
        {/* Dealer Area */}
        <div className="space-y-1 relative z-10">
          <span className="block text-[10px] uppercase font-bold text-emerald-300 text-center tracking-wider">
            Dealer Hand ({gameStage === 'playing' ? '?' : getHandTotal(dealerHand)})
          </span>
          <div className="flex gap-2 justify-center h-20">
            {dealerHand.map((c, i) => {
              const isHidden = gameStage === 'playing' && i === 1;
              return (
                <div 
                  key={i} 
                  className={`w-14 h-20 rounded-lg flex flex-col justify-between p-1.5 border shadow-md relative ${
                    isHidden 
                      ? 'bg-gradient-to-br from-red-600 to-red-800 border-white text-white' 
                      : 'bg-white border-neutral-300 text-black'
                  }`}
                >
                  {isHidden ? (
                    <div className="absolute inset-0 flex items-center justify-center font-bold text-xs uppercase">
                      ♦
                    </div>
                  ) : (
                    <>
                      <div className="text-xs font-bold leading-none flex justify-between">
                        <span>{c.value}</span>
                        <span className={['♥','♦'].includes(c.suit) ? 'text-red-500' : 'text-black'}>{c.suit}</span>
                      </div>
                      <div className={`text-center font-bold text-xl ${['♥','♦'].includes(c.suit) ? 'text-red-500' : 'text-black'}`}>
                        {c.suit}
                      </div>
                      <div className="text-xs font-bold leading-none text-right rotate-180">
                        <span>{c.value}</span>
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Outer outcome overlay */}
        {gameStage === 'result' && (
          <div className="p-3 bg-black/85 border border-amber-500/30 rounded-xl text-center space-y-1 relative z-20 shadow-lg animate-fade-in">
            <h4 className="text-xs font-black text-amber-400 uppercase tracking-widest">{outcomeMessage}</h4>
            <button
              onClick={() => setGameStage('betting')}
              className="px-4 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-[10px] rounded-lg tracking-wider transition cursor-pointer"
            >
              Bet Again
            </button>
          </div>
        )}

        {/* Player Area */}
        <div className="space-y-1 relative z-10">
          <div className="flex gap-2 justify-center h-20">
            {playerHand.map((c, i) => (
              <div 
                key={i} 
                className="w-14 h-20 bg-white border border-neutral-300 rounded-lg flex flex-col justify-between p-1.5 text-black shadow-md"
              >
                <div className="text-xs font-bold leading-none flex justify-between">
                  <span>{c.value}</span>
                  <span className={['♥','♦'].includes(c.suit) ? 'text-red-500' : 'text-black'}>{c.suit}</span>
                </div>
                <div className={`text-center font-bold text-xl ${['♥','♦'].includes(c.suit) ? 'text-red-500' : 'text-black'}`}>
                  {c.suit}
                </div>
                <div className="text-xs font-bold leading-none text-right rotate-180">
                  <span>{c.value}</span>
                </div>
              </div>
            ))}
          </div>
          <span className="block text-[10px] uppercase font-bold text-emerald-300 text-center tracking-wider mt-1">
            Your Hand Total: <b className="text-white text-xs">{playerHand.length > 0 ? getHandTotal(playerHand) : 0}</b>
          </span>
        </div>
      </div>

      {/* Betting / Action Panels */}
      {gameStage === 'betting' ? (
        <div className="w-full space-y-4">
          <div className="flex items-center justify-between gap-3 bg-white/5 border border-white/10 p-3 rounded-xl">
            <div className="text-xs">
              <span className="block text-neutral-400">Bet Amount</span>
              <span className="text-base font-extrabold text-amber-400">${bet}</span>
            </div>
            <div className="flex gap-1.5">
              {[10, 25, 50, 100].map(val => (
                <button
                  key={val}
                  onClick={() => {
                    setBet(val);
                    if (soundEnabled) playSound('select');
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition cursor-pointer ${
                    bet === val 
                      ? 'bg-amber-400 text-black border-amber-400' 
                      : 'bg-white/5 text-white border-white/10 hover:bg-white/10'
                  }`}
                >
                  ${val}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={startNewRound}
            className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm rounded-xl tracking-wider uppercase shadow-lg shadow-emerald-500/10 cursor-pointer"
          >
            Deal Cards & Spin
          </button>
        </div>
      ) : (
        <div className="flex gap-4 w-full shrink-0">
          <button
            onClick={handleHit}
            disabled={gameStage !== 'playing'}
            className="flex-1 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold rounded-xl shadow-md transition cursor-pointer disabled:opacity-40"
          >
            HIT
          </button>
          <button
            onClick={handleStand}
            disabled={gameStage !== 'playing'}
            className="flex-1 py-3.5 bg-amber-500 hover:bg-amber-400 text-black font-extrabold rounded-xl shadow-md transition cursor-pointer disabled:opacity-40"
          >
            STAND
          </button>
        </div>
      )}
    </div>
  );
}

/* ==========================================================================
   GAME ENGINE 7: NEON SLOTS (Casino neon reel pull machine)
   ========================================================================== */
interface SlotsGameProps {
  score: number;
  setScore: (score: number) => void;
  updateHighScore: (newScore: number) => void;
  bankroll: number;
  setBankroll: (val: number | ((prev: number) => number)) => void;
  soundEnabled: boolean;
}

const SLOT_SYMBOLS = [
  { char: '🍒', value: 10, bonus: 2 },
  { char: '🍋', value: 15, bonus: 2.5 },
  { char: '🔔', value: 25, bonus: 3 },
  { char: '💎', value: 50, bonus: 5 },
  { char: '🍀', value: 30, bonus: 3.5 },
  { char: '7️⃣', value: 100, bonus: 10 }
];

function NeonSlotsGame({ score, setScore, updateHighScore, bankroll, setBankroll, soundEnabled }: SlotsGameProps) {
  const [reels, setReels] = useState<string[]>(['🍒', '🍒', '🍒']);
  const [bet, setBet] = useState<number>(20);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [outcome, setOutcome] = useState<string>('');

  const spin = () => {
    if (isSpinning) return;
    if (bankroll < bet) {
      alert("Insufficient chips! Resetting bankroll to $500.");
      setBankroll(500);
      return;
    }

    if (soundEnabled) playSound('jump');
    setBankroll(prev => prev - bet);
    setIsSpinning(true);
    setOutcome('');

    // Dynamic flashing reel animation
    let count = 0;
    const interval = setInterval(() => {
      setReels([
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)].char,
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)].char,
        SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)].char
      ]);
      count += 1;
      if (count >= 15) {
        clearInterval(interval);
        
        // Final roll
        const r1 = SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)];
        const r2 = SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)];
        const r3 = SLOT_SYMBOLS[Math.floor(Math.random() * SLOT_SYMBOLS.length)];
        const finalReels = [r1.char, r2.char, r3.char];
        setReels(finalReels);
        setIsSpinning(false);

        // Score logic
        if (r1.char === r2.char && r2.char === r3.char) {
          // JACKPOT match 3!
          const prize = Math.floor(bet * r1.bonus);
          setBankroll(p => p + prize);
          setScore(score + 150);
          updateHighScore(score + 150);
          setOutcome(`JACKPOT! 3x matching ${r1.char} pays out $${prize}!`);
          if (soundEnabled) playSound('win');
        } else if (r1.char === r2.char || r2.char === r3.char || r1.char === r3.char) {
          // Double match 2
          const matchSym = (r1.char === r2.char || r1.char === r3.char) ? r1 : r2;
          const prize = Math.floor(bet * (matchSym.bonus / 2));
          setBankroll(p => p + prize);
          setScore(score + 50);
          updateHighScore(score + 50);
          setOutcome(`Nice! 2x matching ${matchSym.char} pays out $${prize}!`);
          if (soundEnabled) playSound('score');
        } else {
          setOutcome('No matches this time.');
          setScore(Math.max(0, score - 5));
          if (soundEnabled) playSound('hit');
        }
      }
    }, 80);
  };

  return (
    <div className="w-full max-w-sm mx-auto p-4 flex flex-col gap-6 items-center">
      
      {/* Slot Machine Frame */}
      <div className="w-full aspect-[4/3] bg-purple-950 border-4 border-purple-800 rounded-3xl p-6 shadow-2xl flex flex-col justify-between relative overflow-hidden">
        <div className="absolute -top-10 -left-10 w-40 h-40 rounded-full bg-pink-500/10 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-10 -right-10 w-40 h-40 rounded-full bg-cyan-500/10 blur-2xl pointer-events-none" />

        <div className="text-center">
          <span className="inline-block px-3 py-1 bg-black/50 border border-purple-500/30 rounded-full text-[10px] font-black text-pink-400 uppercase tracking-widest">
            Retro Slot Machine
          </span>
        </div>

        {/* Reels Frame */}
        <div className="grid grid-cols-3 gap-4 bg-black/80 border border-purple-500/20 p-4 rounded-2xl shadow-inner relative">
          {reels.map((symbol, i) => (
            <div 
              key={i} 
              className={`aspect-square rounded-xl bg-[#0d0e14] border border-white/5 flex items-center justify-center text-4xl shadow-md transform transition-all ${
                isSpinning ? 'scale-95 brightness-90 animate-pulse' : 'scale-100'
              }`}
            >
              {symbol}
            </div>
          ))}
        </div>

        {/* Outcome Line */}
        <div className="text-center h-5">
          {outcome && (
            <p className="text-xs font-mono font-bold text-amber-400 animate-fade-in">
              {outcome}
            </p>
          )}
        </div>
      </div>

      {/* Betting and spin action */}
      <div className="w-full space-y-4 shrink-0">
        <div className="flex items-center justify-between gap-3 bg-white/5 border border-white/10 p-3 rounded-xl">
          <div className="text-xs">
            <span className="block text-neutral-400">Pull Bet</span>
            <span className="text-base font-extrabold text-amber-400">${bet}</span>
          </div>
          <div className="flex gap-1.5">
            {[10, 20, 50, 100].map(val => (
              <button
                key={val}
                onClick={() => {
                  setBet(val);
                  if (soundEnabled) playSound('select');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition cursor-pointer ${
                  bet === val 
                    ? 'bg-pink-500 text-white border-pink-500' 
                    : 'bg-white/5 text-white border-white/10 hover:bg-white/10'
                }`}
              >
                ${val}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={spin}
          disabled={isSpinning}
          className="w-full py-4 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-extrabold text-sm rounded-xl tracking-wider uppercase shadow-lg shadow-pink-500/25 cursor-pointer disabled:opacity-55 active:scale-98 transition duration-150"
        >
          {isSpinning ? 'SPINNING...' : 'PULL HANDLE (SPIN)'}
        </button>
      </div>
    </div>
  );
}

/* ==========================================================================
   GAME ENGINE 8: MEMORY MATCH (Arcade icon pairs match)
   ========================================================================== */
interface MemoryProps {
  isPlaying: boolean;
  isGameOver: boolean;
  setIsGameOver: (val: boolean) => void;
  score: number;
  setScore: (score: number | ((prev: number) => number)) => void;
  updateHighScore: (newScore: number) => void;
  soundEnabled: boolean;
  restartTrigger: number;
}

const MEMORY_EMOJIS = ['🎮', '🏆', '⭐', '⚡', '🛡️', '🔥', '💎', '🔑'];

function MemoryMatchGame({ isPlaying, isGameOver, setIsGameOver, score, setScore, updateHighScore, soundEnabled, restartTrigger }: MemoryProps) {
  const [cards, setCards] = useState<Array<{ id: number, char: string, isFlipped: boolean, isMatched: boolean }>>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [moves, setMoves] = useState<number>(0);

  const initBoard = useCallback(() => {
    const list = [...MEMORY_EMOJIS, ...MEMORY_EMOJIS]
      .sort(() => Math.random() - 0.5)
      .map((char, index) => ({
        id: index,
        char,
        isFlipped: false,
        isMatched: false
      }));
    setCards(list);
    setFlippedIndices([]);
    setMoves(0);
    setScore(0);
    setIsGameOver(false);
  }, [setScore, setIsGameOver]);

  // Restart trigger
  useEffect(() => {
    initBoard();
  }, [restartTrigger, initBoard]);

  const handleCardClick = (index: number) => {
    if (isGameOver || !isPlaying) return;
    if (cards[index].isFlipped || cards[index].isMatched) return;
    if (flippedIndices.length >= 2) return;

    if (soundEnabled) playSound('select');

    // Flip card
    const nextCards = [...cards];
    nextCards[index].isFlipped = true;
    setCards(nextCards);

    const nextFlipped = [...flippedIndices, index];
    setFlippedIndices(nextFlipped);

    if (nextFlipped.length === 2) {
      setMoves(m => m + 1);
      const [first, second] = nextFlipped;

      if (cards[first].char === cards[second].char) {
        // Matched!
        setTimeout(() => {
          const matchedCards = [...cards];
          matchedCards[first].isMatched = true;
          matchedCards[second].isMatched = true;
          setCards(matchedCards);
          setFlippedIndices([]);

          setScore(s => {
            const nextScore = s + 25;
            updateHighScore(nextScore);
            return nextScore;
          });
          if (soundEnabled) playSound('score');

          // Win game condition
          if (matchedCards.every(c => c.isMatched)) {
            setIsGameOver(true);
            if (soundEnabled) playSound('win');
          }
        }, 500);
      } else {
        // No match - Flip back
        setTimeout(() => {
          const flippedBack = [...cards];
          flippedBack[first].isFlipped = false;
          flippedBack[second].isFlipped = false;
          setCards(flippedBack);
          setFlippedIndices([]);
          setScore(s => Math.max(0, s - 2));
        }, 850);
      }
    }
  };

  return (
    <div className="w-full max-w-sm mx-auto p-4 flex flex-col gap-4 items-center">
      
      <div className="text-center">
        <span className="text-xs font-mono font-bold text-neutral-400">
          Turns (Moves): <b className="text-white text-sm">{moves}</b>
        </span>
      </div>

      <div className="grid grid-cols-4 gap-3 bg-black/40 border border-white/10 p-4 rounded-2xl w-full aspect-square shrink-0">
        {cards.map((card, index) => {
          const showFace = card.isFlipped || card.isMatched;
          return (
            <button
              key={card.id}
              onClick={() => handleCardClick(index)}
              className={`aspect-square rounded-xl border flex items-center justify-center text-2xl font-bold shadow-md cursor-pointer transition-all duration-300 ${
                showFace 
                  ? 'bg-emerald-500/10 border-emerald-500/50 text-white rotate-y-180 scale-100' 
                  : 'bg-white/5 border-white/10 hover:border-emerald-500/30 scale-98 hover:scale-100'
              }`}
              title="Reveal Card"
            >
              {showFace ? card.char : '❓'}
            </button>
          );
        })}
      </div>

      <button
        onClick={initBoard}
        className="px-6 py-2.5 bg-white/5 border border-white/10 hover:bg-white/10 text-white font-semibold text-xs rounded-xl transition cursor-pointer"
      >
        Reset Memory Deck
      </button>
    </div>
  );
}
