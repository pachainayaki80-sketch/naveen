import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Play, Award, Star, User } from 'lucide-react';
import { Game } from '../types';

interface HeroBannerProps {
  featuredGames: Game[];
  onPlayGame: (game: Game) => void;
  onOpenDetails: (game: Game) => void;
  isDarkMode: boolean;
}

export default function HeroBanner({
  featuredGames,
  onPlayGame,
  onOpenDetails,
  isDarkMode
}: HeroBannerProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto scroll every 6 seconds
  useEffect(() => {
    if (featuredGames.length === 0) return;
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % featuredGames.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [featuredGames]);

  const handlePrev = () => {
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? featuredGames.length - 1 : prevIndex - 1
    );
  };

  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % featuredGames.length);
  };

  if (featuredGames.length === 0) return null;

  const activeGame = featuredGames[currentIndex];

  return (
    <div id="hero-banner-section" className="relative w-full overflow-hidden rounded-3xl group mb-8 shadow-2xl border border-white/5">
      {/* Animated Glowing Ambient Background Gradient Overlay */}
      <div className="absolute inset-0 z-0 bg-gradient-to-r from-emerald-500/10 via-cyan-600/5 to-transparent animate-pulse duration-[6000ms]" />

      <div className={`relative z-10 w-full min-h-[420px] md:min-h-[480px] lg:min-h-[520px] flex flex-col justify-end p-6 md:p-12 lg:p-16 transition-all duration-500 ${
        isDarkMode 
          ? 'bg-gradient-to-t from-[#07080c] via-[#07080c]/60 to-transparent' 
          : 'bg-gradient-to-t from-white via-white/65 to-transparent'
      }`}>
        
        {/* Visual Game Background Image with Blur Transition */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <img
            src={activeGame.image}
            alt={activeGame.name}
            className="w-full h-full object-cover object-center scale-105 transition-all duration-1000 ease-out filter brightness-[0.45] group-hover:scale-100"
          />
          {/* Neon Grid Mesh Accent on Background */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-transparent via-[#07080c]/30 to-[#07080c]/90" />
        </div>

        {/* Content Details Grid */}
        <div className="max-w-3xl space-y-4 md:space-y-6">
          
          {/* Badge Indicators */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest bg-black/40 backdrop-blur-sm border border-white/20 text-emerald-400">
              <Award className="w-3.5 h-3.5 text-emerald-400" />
              Featured Game
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-white/5 border border-white/10 text-cyan-300 backdrop-blur-md">
              {activeGame.category}
            </span>
            <span className="flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-black/40 text-yellow-400 border border-white/10 backdrop-blur-md">
              <Star className="w-3.5 h-3.5 fill-current" />
              {activeGame.rating}
            </span>
          </div>

          {/* Game Title with Display Typography */}
          <h1 className="font-display font-black text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-white tracking-tight leading-tight drop-shadow-lg">
            {activeGame.name}
          </h1>

          {/* Description */}
          <p className="text-neutral-200 text-sm md:text-base lg:text-lg font-sans max-w-2xl leading-relaxed drop-shadow-md line-clamp-3">
            {activeGame.description}
          </p>

          {/* Info row */}
          <div className="flex items-center gap-4 text-xs md:text-sm text-neutral-300">
            <div className="flex items-center gap-1.5">
              <User className="w-4 h-4 text-emerald-400" />
              <span>Dev: <b>{activeGame.developer}</b></span>
            </div>
          </div>

          {/* Interactive Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onPlayGame(activeGame)}
              className="flex items-center gap-2 px-8 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-sm tracking-wide shadow-xl shadow-emerald-500/20 transform transition active:scale-95 cursor-pointer duration-300"
            >
              <Play className="w-4.5 h-4.5 fill-current" />
              Play Now
            </button>
            <button
              onClick={() => onOpenDetails(activeGame)}
              className="px-8 py-3.5 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20 text-white font-extrabold text-sm tracking-wide transition cursor-pointer duration-300"
            >
              Learn More
            </button>
          </div>

        </div>

        {/* Carousel Navigation Indicator Dots */}
        <div className="absolute bottom-6 right-6 md:right-12 flex items-center gap-2">
          {featuredGames.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                idx === currentIndex 
                  ? 'bg-emerald-400 w-8 shadow-neon-emerald' 
                  : 'bg-neutral-500/50 hover:bg-neutral-300'
              }`}
              title={`Slide ${idx + 1}`}
            />
          ))}
        </div>

        {/* Manual Arrow Navigations */}
        <button
          onClick={handlePrev}
          className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-emerald-500 hover:text-black text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 cursor-pointer backdrop-blur-sm z-20"
          title="Previous slide"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <button
          onClick={handleNext}
          className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 hover:bg-emerald-500 hover:text-black text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 cursor-pointer backdrop-blur-sm z-20"
          title="Next slide"
        >
          <ChevronRight className="w-6 h-6" />
        </button>

      </div>
    </div>
  );
}
