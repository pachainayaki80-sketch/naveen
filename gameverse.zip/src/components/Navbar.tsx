import { useState } from 'react';
import { Search, Sun, Moon, Gamepad2, Heart, Menu, X, Info, PhoneCall, Compass, Trophy, Sparkles, Clock } from 'lucide-react';
import { ActiveTab } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isDarkMode: boolean;
  setIsDarkMode: (dark: boolean) => void;
  favoritesCount: number;
}

export default function Navbar({
  activeTab,
  setActiveTab,
  searchQuery,
  setSearchQuery,
  isDarkMode,
  setIsDarkMode,
  favoritesCount
}: NavbarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home', icon: Compass },
    { id: 'categories', label: 'Categories', icon: Gamepad2 },
    { id: 'popular', label: 'Popular', icon: Trophy },
    { id: 'new', label: 'New Games', icon: Sparkles },
    { id: 'trending', label: 'Trending', icon: Clock },
    { id: 'favorites', label: `My Wishlist (${favoritesCount})`, icon: Heart, badge: favoritesCount },
    { id: 'about', label: 'About', icon: Info },
    { id: 'contact', label: 'Contact', icon: PhoneCall },
  ];

  const handleNavClick = (tabId: ActiveTab) => {
    setActiveTab(tabId);
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className={`sticky top-0 z-50 transition-all duration-300 border-b ${
      isDarkMode 
        ? 'bg-[#07080c]/75 border-white/10 text-white backdrop-blur-xl shadow-glass' 
        : 'bg-white/65 border-black/10 text-neutral-800 backdrop-blur-xl shadow-sm'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo */}
          <div 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2 cursor-pointer shrink-0"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-500 p-0.5 shadow-lg shadow-emerald-500/20 flex items-center justify-center transition-transform hover:scale-105 duration-300">
              <div className="w-full h-full bg-[#0d0e14] rounded-[10px] flex items-center justify-center">
                <Gamepad2 className="w-5.5 h-5.5 text-emerald-400" />
              </div>
            </div>
            <span className="font-display font-extrabold text-xl tracking-tight text-white">
              Game<span className="text-emerald-400">Verse</span>
            </span>
          </div>

          {/* Search Bar - Play Store Style */}
          <div className="hidden md:flex flex-1 max-w-md relative mx-4">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search games, developers, categories..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (activeTab !== 'search' && activeTab !== 'home') {
                  setActiveTab('search');
                }
              }}
              className={`w-full pl-10 pr-4 py-2.5 rounded-full text-sm outline-none transition-all duration-300 border ${
                isDarkMode 
                  ? 'bg-white/5 border-white/10 text-white focus:bg-white/10 focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 placeholder-neutral-500' 
                  : 'bg-black/5 border-black/10 text-neutral-800 focus:bg-white focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/20 placeholder-neutral-400'
              }`}
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs text-neutral-400 hover:text-neutral-200"
              >
                Clear
              </button>
            )}
          </div>

          {/* Right Action Items */}
          <div className="flex items-center gap-2">
            {/* Wishlist quick link (icon only on mobile) */}
            <button
              onClick={() => handleNavClick('favorites')}
              className={`p-2.5 rounded-xl transition-all relative ${
                activeTab === 'favorites'
                  ? 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20'
                  : 'text-neutral-400 hover:text-emerald-400 hover:bg-emerald-500/5'
              }`}
              title="My Favorites"
            >
              <Heart className="w-5 h-5 fill-current" />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 text-[10px] font-bold text-white shadow-sm">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2.5 rounded-xl text-neutral-400 hover:text-emerald-400 hover:bg-emerald-500/5 transition-all"
              title="Toggle Theme"
            >
              {isDarkMode ? <Sun className="w-5 h-5 text-yellow-400" /> : <Moon className="w-5 h-5 text-neutral-600" />}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-all"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Desktop Sub-navigation list */}
      <div className={`hidden md:block border-t ${
        isDarkMode ? 'bg-[#0d0e14]/50 border-white/5' : 'bg-white/45 border-black/5'
      } backdrop-blur-md`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-1 py-2 overflow-x-auto no-scrollbar">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id as ActiveTab)}
                  className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all shrink-0 cursor-pointer ${
                    isActive
                      ? isDarkMode
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 shadow-neon-emerald/5'
                        : 'bg-emerald-500/10 text-emerald-700 border border-emerald-500/20'
                      : isDarkMode
                        ? 'text-neutral-400 hover:text-white hover:bg-white/5 border border-transparent'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-black/5 border border-transparent'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-neutral-400'}`} />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className={`md:hidden px-4 pt-2 pb-6 border-t ${
          isDarkMode ? 'bg-neutral-950 border-neutral-800' : 'bg-white border-neutral-200'
        } transition-all duration-300`}>
          
          {/* Mobile Search */}
          <div className="relative mb-4 mt-2">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-neutral-400" />
            </div>
            <input
              type="text"
              placeholder="Search games..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (activeTab !== 'search') {
                  setActiveTab('search');
                }
              }}
              className={`w-full pl-9 pr-4 py-2 rounded-full text-sm outline-none transition-all border ${
                isDarkMode 
                  ? 'bg-white/5 border-white/10 text-white focus:border-emerald-500/50' 
                  : 'bg-black/5 border-black/10 text-neutral-800 focus:bg-white focus:border-emerald-500'
              }`}
            />
          </div>

          {/* Navigation Links */}
          <div className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id as ActiveTab)}
                  className={`w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                    isActive
                      ? isDarkMode
                        ? 'bg-emerald-500/10 text-emerald-400 border-l-4 border-emerald-500'
                        : 'bg-emerald-500/10 text-emerald-700 border-l-4 border-emerald-500'
                      : isDarkMode
                        ? 'text-neutral-400 hover:text-white hover:bg-white/5'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-black/5'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4 text-neutral-400" />
                    <span>{item.label}</span>
                  </div>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="px-2 py-0.5 rounded-full text-xs bg-emerald-500 text-white font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </nav>
  );
}
