export interface Game {
  id: string;
  name: string;
  category: string;
  image: string;
  rating: number;
  developer: string;
  description: string;
  play_url: string;
}

export type ActiveTab = 'home' | 'categories' | 'popular' | 'new' | 'trending' | 'search' | 'about' | 'contact' | 'favorites';

export interface FilterState {
  searchQuery: string;
  category: string;
  sortBy: 'rating' | 'name' | 'default';
}

export interface ContactForm {
  name: string;
  email: string;
  subject: string;
  message: string;
}
